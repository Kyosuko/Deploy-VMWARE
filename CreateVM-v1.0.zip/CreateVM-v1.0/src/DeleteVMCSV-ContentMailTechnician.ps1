"<head><style>.progress-bar-red { width:$($PourcentDeleteVMFailCSS)px;height: 24px;padding: 4px;background: linear-gradient(#ff0000,#000000);border-radius: 16px;
-webkit-border-radius: 16px;-moz-border-radius: 16px;box-shadow: inset 0 1px 2px #000, 0 1px 0 #2b2b2b;-webkit-box-shadow: inset 0 1px 2px #000, 0 1px 0 #2b2b2b;-moz-box-shadow: inset 0 1px 2px #000, 0 1px 0 #2b2b2b;
}</style></head>
Hi, <b>$NameTechnicianBodyHTML</b> <p/> In this mail you can see the report sended about what happened on vSphere : <b>$NamevSphereServer</b><br><br>
<b>Virtual machine not deleted : <font color=red><b>$($line.name)</font></b>
<div class=progress-bar-red><center><font color=white>N. $HTMLVMFail</font></center></div>
<br>Account used for the attempt of deletion : <b><u><font color=1155CC>$UservSphereServer</b></font></u>
<i><u><brList of parameters used during the attempt to delete this virtual machine :<br><br><br>
<center><table><tr><th>Name</th></tr>
<tr><td>$($line.name)</td></tr></center></table>
<i><u><br>List of errors during the attempt to delete a virtual machine  at <b>$Hour hours $Minute minutes</u></i> :<br>"