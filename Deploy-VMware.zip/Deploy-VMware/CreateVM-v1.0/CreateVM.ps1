##########################################################################
##                                                                      ##
##                          Version : 1.0                               ##
##                    Created by : Kyosuko                              ##
##                      Recipient : xx                                  ##							![Also sorry to my bad way to write english.]!
##                     Release Date : 20/11/2020                        ##							![Also sorry to my bad way to write english.]!
##                      Name : CreateVM.ps1                             ##
##                                                                      ##
##########################################################################
#####(0) First part  of script - Functions used by the script ############
##########################################################################

## Variables used which allows to be used by all functions
$script:ChoiceYes="Y" # When the user have a choice allows to say condition equal to "Y"
$script:ChoiceNo="N" # When the user have a choice allows to say condition equal to "N"
$script:LocationScript=Get-Location # Allows to get a location where is launched the script and search the sources used by the script in the folder /src and /data
$script:PathSecurityPasswordMail="$LocationScript\data\tmpmail.tcsrc3" # Allows to known the path which contained the password crypted in mode automatic for mails
$script:PathSecurityPasswordvSphere="$LocationScript\data\tmpvsphere.tcsrc3" # Allows to known the path which contained the password crypted in mode automatic for vSphere
$script:PathSecurityPasswordManual="$LocationScript\data\tmpmnl.tcsrc3" # Allows to known where must be save the file contained the password crypted in mode manual
$script:KeyCrypt=[byte]25,12,78,45,12,11,98,82,21,34,87,91,20,05,96,92 # Allows to know the key to encrypt the password in mode automatic if you not used the default
$script:JumpHTML="<p/>" # Allows to Jump a line in the code HTML specialy for technician mails
$script:Delimiter=";" # Allows to define the delimiter which must be used in the CSV file to be read correctly

#################### Modify informations in mode automatic ####################
# Line 104-105 contains the credentials to connect vSphere in mode automatic
# Line 205 206 contains the crendentials about smtp server in mode automatic
# Line 236 contains the mail address which receveil the mail test
# Line 240 contains the mail address which will be use to send the mails
# Line 298-300 contains the lists addresses of recipients
###############################################################################
## * The mode manual is declenched when the informations entered in the script
##   (automatic) are not valide so the fields appears
###############################################################################


###########################################################################
##### List of functions
###########################################################################

## Function JumpLine
# Allows to Jump a line without use ` or another chain of character empty
Function Jumpline {
	# Put an empty string to jumpline
	""
}

## Function CreateVMCSV
# Allows to create many virtual machines since a CSV File and purpose the choice
# to start vm after creation also send mail with reports
Function CreateVMCSV {
	# Ask the user to specify the location of the CSV containing the parameters of the VM
	write-host "You want create virtual machines since a CSV file" -ForegroundColor gray
	write-host 'WARNING : The delimiter in the CSV file must be ";" in order to be able to create virtual machines' -ForegroundColor yellow
	$LocationCSV="$LocationScript\data\KyosukoSRC3.csv"
	# Check if the CSV file exists with the extension .csv
	$CheckLocationCSV=Get-Item $LocationCSV ; $CheckLocationCSV.Extension
	# If the file exists, a message, success and warning is displayed
	if ($CheckLocationCSV.Extension -eq ".csv") {
    	write-host "SUCCES : The file specifed exist with the good extension .csv" -ForegroundColor green
    	write-host 'WARNING : If you don''t use the delimiter ";" in the CSV file you must change else not working correctly'  -ForegroundColor yellow
	}
	# As long as the file specified in the $LocationCSV variable is not a csv file, a new entry is displayed with an error message
	else {
		write-host 'ERROR : The file than you have specify is not valide check if it''s the good path or if there are the extension ".csv"
restart the script with the good path of csv file' -ForegroundColor red
	}
	# Check than for the first line there are a delimiter ";"
	# A timeout between the last action and the new 
	timeout /t 5
	$CheckDelimiter=Get-content $LocationCSV | Select -First 1
	if ($CheckDelimiter -like "*;*"){
		write-host 'SUCCES : The delimiter used is ";"' -ForegroundColor Green
	}
	else {
		write-host 'ERROR : You don''use the delimiter ";" please use it and retry' -ForegroundColor red
		write-host "Exit script in 10 seconds" -ForegroundColor Gray
		timeout /t 10
		LeaveScript
	}
	# A timeout between the last action and the new then importation the CSV file and display message success, information and warning
	# Also a message with version PowerShell is displayed
	timeout /t 5
	Import-CSV -Path $LocationCSV -Delimiter $Delimiter | Format-table
	write-host "SUCCES : Import successful" -ForegroundColor green
	write-host "WARNING : If you not see correctly the table with the values it's because the file is empty or you don't use the good delimiter so solve this problem else problem during creation VMs" -ForegroundColor yellow
	timeout /t 5
	JumpLine
	write-host 'WARNING : To use Power CLI you must have a version PowerShell "5" at least if this is not the case `
upgrade to continue, otherwise the utility will not work properly' -ForegroundColor yellow
	write-host "INFORMATION : Your PowerShell version is as follows :" $PSVersionTable.PSVersion.Major -ForegroundColor gray
	# A check of version PowerShell is "5" or upper and if it's okay display message success else a error message and propose 
	# if he want upgrade PowerShell a message display how to upgrade else return to the homepage
	if ((($Host.Version.Major) -eq 5) -or (($Host.Version.Major)-gt [int]5)) {
		Write-host 'SUCCES : You have version "5" it''s okay' -ForegroundColor green
	}
	else {
    	write-host 'ERROR : You don''t have version "5", please upgrade your PS' -ForegroundColor red
			write-host "INFORMATION : To Upgrade you power-shell you must download minimum .NetFramwork 4.5 and WMF 5.0 (With KB)" -ForegroundColor gray
			write-host "INFORMATION : Or download minimum .NetFramwork 4.5 and install with msi" -ForegroundColor gray
			write-host "Exit script in 30 seconds" -ForegroundColor Gray
			timeout /t 30
			LeaveScript
    }
	# A timeout between the last action the next action "PowerCLI"
	timeout /t 5
	JumpLine
	write-host "INFORMATION : Now you are able to connect to vSphere for creation of VMs" -ForegroundColor gray
	write-host "INFORMATION : Please wait attempt to connect to vSphere" -ForegroundColor gray
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer="vcenter"
	$UservSphereServer="administrator@vsphere.local"
	try{ #(Mode automatic)
		# Command to connect on the vSphere (Mode automatic)
		# Path $PathSecurityPasswordvSphere contains the file with password crypted
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPasswordvSphere | ConvertTo-SecureString -Key $KeyCrypt)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validate, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials (Mode manual) and if it's good message succes is displayed
		while ($?-eq $false) {
			# Remove the file which contains the password crypted
			Remove-Item $PathSecurityPasswordManual
			write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPasswordManual -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validate, Welcome" -ForegroundColor green
				Remove-Item $PathSecurityPasswordManual
			}
		}
	}
	# Allows to count the number of line without the first and spaces and got the number of virtual machines than
	# the user want create
	$CheckNBVM=Get-content $LocationCSV | Where-Object { $_ } | Measure-Object
	$NBVM=$CheckNBVM.count-1
	# Allows to count the number of delimiter ";" and find if there are are error (Ex : Not same number of parameter for each line)
	# If it's good display count the totality of virtual machines the user want create else error message display and return to the homepage
	[int]$CutLast = $Null 
	Get-Content $LocationCSV | ? {$_} | % {
	if($CutLast -and !($_.split(";").count -eq $CutLast)){
		write-host"ERROR : ! There is a problem on the line $($_.psobject.Properties.value[5]) of the CSV file incorrect number of parameters`
		compared to others ! Try resolve this issue" -ForegroundColor red
		write-host "Exit script in 15 seconds" -ForegroundColor Gray
		timeout /t 15
		LeaveScript
	
	}
	elseif (!$CutLast){
		$CutLast = $_.split(";").count
	}
	# Display the number of virtual machines asked to create and number of parameters with timeout between this action and ask continue
	write-host "INFORMATION : There are " $NBVM "virtual machines that will be create" -ForegroundColor gray
	write-host "INFORMATION : These virtual machines will be created with $CutLast settings" -ForegroundColor gray
	timeout /t 10
	# Check if Telnet is installed to tester to connection between server mail
	write-host "WARNING : To send emails telnet is required to do a connection test" -ForegroundColor yellow
	# Commands to check if telnet is installed and get the version of Windows (Server, Workstation)
	$CheckTelnet=get-command -name *telnet*
	$CheckVersionWindows=Get-WmiObject Win32_OperatingSystem | Select-Object "Caption" 
	$GetCheckVersionWindows=$CheckVersionWindows.caption
	if ([string]::IsNullOrEmpty($CheckTelnet)){
		write-host "ERROR : Telnet is not installed" -ForegroundColor red
		# If the version Windows contains the word "Server" (Windows Server) and choice installation telnet is "Y" so installation of functionality Telnet
		# by Dism
		if ($GetCheckVersionWindows -notlike "*Server*"){
			try {
				write-host 'WARNING : Telnet will be installed in 15 seconds it''s necessary to work if you don''t want to make the combination "Ctrl+C"' -ForegroundColor yellow
				timeout /t 15
				dism /Online /Enable-Feature /featurename:TelnetClient -ErrorAction Stop
			}
			catch {
				write-host "ERROR : Telnet has not been installed, try resolve this issue" -ForegroundColor red
				write-host "Exit script in 10 seconds" -ForegroundColor Gray
				timeout /t 10
				LeaveScript
			}
			write-host "SUCCES : Telnet has been installed" -ForegroundColor green
		}
		# If the version Windows contains not the word "Server" (Windows Workstation) and choice installation telnet is "Y" so installation of functionality Telnet
		# by WindowsFeature
		elseif ($GetCheckVersionWindows -like "*Server*"){
			try {
				write-host 'WARNING : Telnet will be installed in 15 seconds it''s necessary to work if you don''t want to make the combination "Ctrl+C"' -ForegroundColor yellow
				timeout /t 15
				Install-WindowsFeature Telnet-Client -ErrorAction Stop
			}
			catch {
				write-host "ERROR : Telnet has not been installed, try resolve this issue" -ForegroundColor red
				write-host "Exit script in 10 seconds" -ForegroundColor Gray
				timeout /t 10
				LeaveScript
			}
			write-host "SUCCES : Telnet has been installed" -ForegroundColor green
		}
	}
	else{
	write-host "SUCCES : Telnet is already installed" -ForegroundColor green
	}
	# Test the connection of server mail via telnet and the crendentials they will be used for send the reports if work (Mode automatic)
	write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
	$FromMailServer="smtp.gmail.com" 
	$FromMailServerPort="587"
	$Testconnection=Test-NetConnection $FromMailServer -port $FromMailServerPort #(Mode automatic)
	# As long as than the test connection not work ask the user to specify the credentials of mail server (Mode manual) to test send mail and they will be used for send the reports if work 
	while ($Testconnection.tcptestsucceeded -eq $false){
		write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
		write-host "ERROR : The connection has not been etablished bad informations used, server state or others retry" -ForegroundColor red
		write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
		$FromMailServer=read-host "Specify the mail server address of sender" 
		[int]$FromMailServerPort=read-host "Specify the port of mail server"
		# As long as than the fields is empty the fills are reasked
		while (([string]::IsNullOrEmpty($FromMailServerPort)) -or ([string]::IsNullOrEmpty($FromMailServer))) {
			write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
			write-host "ERROR : All fields must be filled" -ForegroundColor red
			write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
			$FromMailServer=read-host "Specify the mail server address of sender" 
			[int]$FromMailServerPort=read-host "Specify the port of mail server"
		}
		# Command to test the connection of server mail via Telnet
		$Testconnection=Test-NetConnection $FromMailServer -port $FromMailServerPort     
	}
	# If the command to test the connection of server mail has worked display a message success
	if ($Testconnection.tcptestsucceeded -eq $true){
		Write-Host "SUCCES : The connection has been established" -ForegroundColor green
	}
	# Email address that will be used to receive the test sending email
	write-host "WARNING : To send report by mail a test send mail will be make" -ForegroundColor yellow
	$MailEncodage="UTF8"
	$MailTest="Kyosukoxxxx@gmail.com"
	$SubjectMailTest="Do not Reply : Send mail test about creation of VM"
	$ContentMailTest="Hey, if you receive this mail it's because the send mail work with the credentials"
	# Email address which will be used to send the mail for the recipients of reports and test send mail
	$FromMailUserMail="Kyosukoxxxx@gmail.com"
	try{ #(Mode automatic)
		# Allows to specify the mail the "from" in the mail
		$Mailaddressfrom=$FromMailUserMail
		# Command to send mail test (Mode automatic)
		# Path $PathSecurityPasswordMail contains the file with password crypted
		Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $MailTest -Port $FromMailServerPort -Subject $SubjectMailTest -Body $ContentMailTest -BodyAsHtml -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
		(Get-Content -Path $PathSecurityPasswordMail | ConvertTo-SecureString -Key $KeyCrypt)) -UseSsl -ErrorAction Stop
	}
	catch{ # (Mode manual)
		# Display a message which say pass to mode manual
		write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
		# If the command send mail test has not worked the user must specify the e-mail address and password that will be used to send the report (Mode manual)
		write-host "ERROR : All fields must be filled or the send mail has not worked, try yet" -ForegroundColor red
		$FromMailUserMail=read-host "Specify the mail address of sender" 
		read-host "Specify the password of mail address to sender" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPasswordManual -ErrorAction stop -confirm:$false 
		# As long as than the fields is empty the fills are reasked 
		while ([string]::IsNullOrEmpty($FromMailUserMail)) {
			# Remove the file which contains the password crypted
			Remove-Item $PathSecurityPasswordManual
			write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
			write-host "ERROR : All fields must be filled" -ForegroundColor red
			$FromMailUserMail=read-host "Specify the mail address of sender" 
			read-host "Specify the password of mail address to sender" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPasswordManual -ErrorAction stop -confirm:$false 
		}
		# Allows to specify the mail the "from" in the mail
		$Mailaddressfrom=$FromMailUserMail
		# Command to send mail test
		Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $MailTest -Port $FromMailServerPort -Subject $SubjectMailTest -Body $ContentMailTest -BodyAsHtml -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
		(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
		# As long as command send mail test has not worked the user must specify the e-mail address and password that will be used to send the report 
		while ($? -eq $false){
			write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
			write-host "ERROR : The send mail test has not worked, try resolve this issue" -ForegroundColor red
			Remove-Item $PathSecurityPasswordManual
			$FromMailUserMail=read-host "Specify the mail address of sender" 
			read-host "Specify the password of mail address to sender" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPasswordManual -ErrorAction stop -confirm:$false 
			# As long as than the fields is empty the fills are reasked 
			while ([string]::IsNullOrEmpty($FromMailUserMail)) {
				Remove-Item $PathSecurityPasswordManual
				write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
				write-host "ERROR : All fields must be filled" -ForegroundColor red
				$FromMailUserMail=read-host "Specify the mail address of sender" 
				read-host "Specify the password of mail address to sender" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPasswordManual -ErrorAction stop -confirm:$false 
			}
			# Allows to specify the mail the "from" in the mail
			$Mailaddressfrom=$FromMailUserMail
			# Command to send mail test
			Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $MailTest -Port $FromMailServerPort -Subject $SubjectMailTest -Body $ContentMailTest -BodyAsHtml -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
			(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
		}
	}
	# If the send mail test has worked display a message succes
	if ($? -eq $true){
		Write-Host "SUCCES : The send mail test has worked " -ForegroundColor green
	}
	# Mail addresses of recipients
	# The addresses mail entered will be used like recipients 
	$Technician="Kyosukoxxxx1@gmail.com"
	$Applicant= "Kyosukoxxxx2@gmail.com"
	$Responsible="Kyosukoxxxx3@gmail.com"
	# Display a message creation of virtual machine with timeout
	write-host "WARNING : Creation of virtual machines in 10 seconds" -ForegroundColor Yellow
	timeout /t 10
	# Declaration of variables container the numbers of creation vm success, fail, cancel and a pourcentage also a pourcentage for the gauge in the mail (CSS).
	# Commands to recup only the beginning of address mail before "@"
	# Initialize the variable 
	$CreateVMSucces=0;$CreateVMFail=0;$CreateVMCancel=0
	$StartVMTrue=$null;$IsoVMTrue=$null
	$PourcentCreateVMSucces=0;$PourcentCreateVMSuccesCSS=0;$HTMLVMSucces=0
	$PourcentCreateVMFail=0;$PourcentCreateVMFailCSS=0;$HTMLVMFail=0
	$PourcentCreateVMCancel=0;$PourcentCreateVMCancelCSS=0;$HTMLVMCancel=0
	$Hour=(get-date).Hour
	$Minute=(get-date).Minute
	$NameTechnicianBodyHTML=[regex]::Match($Technician,'^[^@]*').Value
	$NameApplicantBodyHTML=[regex]::Match($Applicant,'^[^@]*').Value
	$NameResponsibleBodyHTML=[regex]::Match($Responsible,'^[^@]*').Value
	# Allows to import CSV file withtout format-table else error during attempt of creation
	$PathCSVFormatNoTable=Import-CSV -Path $LocationCSV -Delimiter $Delimiter
	# Loop for each line in the CSV file and allows to create the virtual machines with command "New VM"
	foreach ($line in $PathCSVFormatNoTable){
			Jumpline 
			write-host "Parameters which will be used for the creation of the virtual machine :"
			# Allows to print the line with parameters of virtual machine
			$line | format-table
			# Ask if the user want create the virtual machine
			$AskCreateVM=read-host "Do you want validate the creation of the virtual machine ? $($line.name)"
			while (($AskCreateVM -ne $ChoiceYes) -and ($AskCreateVM -ne $ChoiceNo)){
				$AskCreateVM=read-host "Do you want validate the creation of the virtual machine ? $($line.name)"
			}
			if ($AskCreateVM -eq $ChoiceYes) {
				write-host "You have chosen to create the virtual machine $($line.name)" -ForegroundColor Cyan
				# Command to create virtual machine
				New-VM -VMHost $line.VMHost -Name $line.Name -Datastore $line.Datastore -ResourcePool $line.RessourcePool -NumCPU $line.NumCPU -MemoryMB $line.MemoryMB -DiskMB $line.DiskMB -DiskStorageFormat $line.DiskStorageFormat -CD -Floppy -Confirm:$false -ErrorVariable VMError 
				if ($? -eq $true){ # If virtual machine created withtout problem
					# Variable which contains the number of virtual machine created
					$CreateVMSucces++
					# Variable which contains the name of virtual machine created for the choice if the user want started the vms after creation
					$StartVMTrue +=, $line.Name 
					# Variable which contains the name of virtual machine created for the choice if the user want connect theiso imported after creation
					$IsoVMTrue +=, $line.Name 
					# [Math]::Floor make a integer division
					$PourcentCreateVMSucces=[Math]::Floor(($CreateVMSucces/$NBVM)*100)
					$PourcentCreateVMSuccesCSS=[Math]::Floor(($CreateVMSucces/$NBVM)*300)
					$HTMLVMSucces="($CreateVMSucces/$NBVM)"
					$SubjectMailApplicant= "Succes for the creation of VM : $($line.name)"
					$ContentMailApplicant=."$LocationScript\src\CreateVMCSV-ContentMailApplicant.ps1"
					Write-Host "SUCCES : The virtual machine" $line.Name "has been created with success" -ForegroundColor green
					# If mode automatic is active and work
					if (![System.IO.File]::Exists($PathSecurityPasswordManual)){ # (Mode automatic)
					# Commands to send mail with reports success to applicant if mode automatic is active and work 
					# Path $PathSecurityPasswordMail contains the file with password crypted
					Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicant -BodyAsHtml $ContentMailApplicant -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
					(Get-Content -Path $PathSecurityPasswordMail | ConvertTo-SecureString -Key $KeyCrypt)) -UseSsl -ErrorAction continue
						while ($? -eq $false){
							write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
							write-host "The mail has not been sended try to check if the mail address specified is correct"
							$Applicant=read-host "Specify the mail address of applicant"
							# Send mail to applicant
							Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicant -BodyAsHtml $ContentMailApplicant -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
							(Get-Content -Path $PathSecurityPasswordMail | ConvertTo-SecureString -Key $KeyCrypt)) -UseSsl -ErrorAction continue
						}
					}
					# If the mode manual is active (file contains password mode manual)
					else{ # (Mode manual)
						# Commands to send mail with reports success to applicant if mode manual is active
						Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicant -BodyAsHtml $ContentMailApplicant -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
						(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
						while ($? -eq $false){
							write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
							write-host "The mail has not been sended try to check if the mail address specified is correct"
							$Applicant=read-host "Specify the mail address of applicant"
							# Send mail to applicant
							Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicant -BodyAsHtml $ContentMailApplicant -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
							(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
						}
					}
				}
				elseif($? -eq $false){ # If virtual machine not created/correctly with problem
					# Variable which contains the number of virtual machine badly created/not created
					$CreateVMFail++
					# [Math]::Floor make a integer division
					$PourcentCreateVMFail=[Math]::Floor(($CreateVMFail/$NBVM)*100)
					$PourcentCreateVMFailCSS=[Math]::Floor(($CreateVMFail/$NBVM)*300)
					$HTMLVMFail="($CreateVMFail/$NBVM)"
					$SubjectMailTechnician="Error during the attempt to create a VM : $($line.name)" 
					$SubjectMailApplicantErr= "Fail for the attempt to create a VM : $($line.name)"
					$CSSMailContent=Get-Content "$LocationScript\src\ContentMail-CSS.tcsrc3"
					$ContentMailTechnician=."$LocationScript\src\CreateVMCSV-ContentMailTechnician.ps1"
					$ContentMailTechnicianEnd=."$LocationScript\src\CreateVMCSV-ContentMailTechnician-End.ps1"
					$ContentMailApplicantErr=."$LocationScript\src\CreateVMCSV-ContentMailApplicantErr.ps1"
					Write-Host "ERROR : The virtual machine $($line.name) has not been created or not created correctly because exists already or others issue" -ForegroundColor red
					# If mode automatic is active and work
					if (![System.IO.File]::Exists($PathSecurityPasswordManual)){ # (Mode automatic)
						# Commands to send mail with reports echec to technician if mode automatic is active and work
						# Path $PathSecurityPasswordMail contains the file with password crypted
						Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Technician -Port $FromMailServerPort -Subject $SubjectMailTechnician -BodyAsHtml ($ContentMailTechnician+$JumpHTML+($VMError | ConvertTo-Html -Property Exception, CategoryInfo, ScriptStackTrace -head $CSSMailContent | out-string)+$ContentMailTechnicianEnd) -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
						(Get-Content -Path $PathSecurityPasswordMail | ConvertTo-SecureString -Key $KeyCrypt)) -UseSsl -ErrorAction continue
						while ($? -eq $false){
							write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
							write-host "The mail has not been sended try to check if the mail address specified is correct"
							$Technician=read-host "Specify the mail address of Technician"
							# Send mail to technician
							Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Technician -Port $FromMailServerPort -Subject $SubjectMailTechnician -BodyAsHtml ($ContentMailTechnician+$JumpHTML+($VMError | ConvertTo-Html -Property Exception, CategoryInfo, ScriptStackTrace -head $CSSMailContent | out-string)+$ContentMailTechnicianEnd) -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
							(Get-Content -Path $PathSecurityPasswordMail | ConvertTo-SecureString -Key $KeyCrypt)) -UseSsl -ErrorAction continue
						}
						# Commands to send mail with reports fail to applicant if mode automatic is active and work
						Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicantErr -BodyAsHtml $ContentMailApplicantErr -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
						(Get-Content -Path $PathSecurityPasswordMail | ConvertTo-SecureString -Key $KeyCrypt)) -UseSsl -ErrorAction continue
						while ($? -eq $false){
							write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
							write-host "The mail has not been sended try to check if the mail address specified is correct"
							$Applicant=read-host "Specify the mail address of applicant"
							# Send mail to applicant
							Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicantErr -BodyAsHtml $ContentMailApplicantErr -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
							(Get-Content -Path $PathSecurityPasswordMail | ConvertTo-SecureString -Key $KeyCrypt)) -UseSsl -ErrorAction continue
						}
					}
					# If the mode manual is active (file contains password mode manual)
					else{ # (Mode manual)
						# Commands to send mail with reports echec to technician if mode manual is active 
						Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Technician -Port $FromMailServerPort -Subject $SubjectMailTechnician -BodyAsHtml ($ContentMailTechnician+$JumpHTML+($VMError | ConvertTo-Html -Property Exception, CategoryInfo, ScriptStackTrace -head $CSSMailContent | out-string)+$ContentMailTechnicianEnd) -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
						(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
						while ($? -eq $false){
							write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
							write-host "The mail has not been sended try to check if the mail address specified is correct"
							$Technician=read-host "Specify the mail address of technician"
							# Send mail to technician
							Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Technician -Port $FromMailServerPort -Subject $SubjectMailTechnician -BodyAsHtml ($ContentMailTechnician+$JumpHTML+($VMError | ConvertTo-Html -Property Exception, CategoryInfo, ScriptStackTrace -head $CSSMailContent | out-string)+$ContentMailTechnicianEnd) -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
							(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
						}
						# Commands to send mail with reports fail to applicant if mode manual is active 
						Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicantErr -BodyAsHtml $ContentMailApplicantErr -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
						(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
						while ($? -eq $false){
							write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
							write-host "The mail has not been sended try to check if the mail address specified is correct"
							$Applicant=read-host "Specify the mail address of applicant"
							# Send mail to applicant
							Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicantErr -BodyAsHtml $ContentMailApplicantErr -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
							(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
						}
					}
				}
			}
			elseif ($AskCreateVM -eq $ChoiceNo) { # If virtual machine not created by cancel
				write-host "You have chosen to not create the virtual machine $($line.name)" -ForegroundColor Magenta
				# Variable which contains the number of virtual machine canceled
				$CreateVMCancel++
				# [Math]::Floor make a integer division
				$PourcentCreateVMCancel=[Math]::Floor(($CreateVMCancel/$NBVM)*100)
				$PourcentCreateVMCancelCSS=[Math]::Floor(($CreateVMCancel/$NBVM)*300)
				$HTMLVMCancel="($CreateVMCancel/$NBVM)"
				$SubjectMailApplicantCancel= "Request canceled to create a VM : $($line.name)"
				$ContentMailApplicantCancel=."$LocationScript\src\CreateVMCSV-ContentMailApplicantCancel.ps1"
				# If mode automatic is active and work
				if (![System.IO.File]::Exists($PathSecurityPasswordManual)){ # (Mode automatic)
					# Commands to send mail with reports canceled to applicant if mode automatic is active and work 
					# Path $PathSecurityPasswordMail contains the file with password crypted
					Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicantCancel -BodyAsHtml $ContentMailApplicantCancel -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
					(Get-Content -Path $PathSecurityPasswordMail | ConvertTo-SecureString -Key $KeyCrypt)) -UseSsl -ErrorAction continue
					while ($? -eq $false){
						write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
						write-host "The mail has not been sended try to check if the mail address specified is correct"
						$Applicant=read-host "Specify the mail address of applicant"
						# Send mail to applicant (select not create - cancel) 
						Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicantCancel -BodyAsHtml $ContentMailApplicantCancel -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
						(Get-Content -Path $PathSecurityPasswordMail | ConvertTo-SecureString -Key $KeyCrypt)) -UseSsl -ErrorAction continue
					}
				}
				# If the mode manual is active (file contains password mode manual)
				else{ # (Mode manual)
					# Commands to send mail with reports canceled to applicant if mode manual is active
					Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicantCancel -BodyAsHtml $ContentMailApplicantCancel -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
					(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
					while ($? -eq $false){
						write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
						write-host "The mail has not been sended try to check if the mail address specified is correct"
						$Applicant=read-host "Specify the mail address of applicant"
						# Send mail to applicant (select not create - cancel) 
						Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicantCancel -BodyAsHtml $ContentMailApplicantCancel -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
						(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
					}
				}
			}
		}
		# Display a message with the total of virtual machine created, not created and canceled
		write-host "INFORMATION : $CreateVMSucces virtual machines have been created, $CreateVMFail not created/correctly with error and $CreateVMCancel canceled" -ForegroundColor gray
		$SubjectMailResponsible="Report all VMs creations"
		$ContentMailResponsible=."$LocationScript\src\CreateVMCSV-ContentMailResponsible.ps1"
		# If mode automatic is active and work
		if (![System.IO.File]::Exists($PathSecurityPasswordManual)){ # (Mode automatic)
			write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
			# Commands to send mail with reports to Reponsible if mode automatic is active and work 
			# Path $PathSecurityPasswordMail contains the file with password crypted
			Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Responsible -Port $FromMailServerPort -Subject $SubjectMailResponsible -BodyAsHtml $ContentMailResponsible -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
			(Get-Content -Path $PathSecurityPasswordMail | ConvertTo-SecureString -Key $KeyCrypt)) -UseSsl -ErrorAction continue
			while ($? -eq $false){
				write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
				write-host "The mail has not been sended try to check if the mail address specified is correct"
				$Responsible=read-host "Specify the mail address of responsible"
				# Send mail to Responsible
				Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Responsible -Port $FromMailServerPort -Subject $SubjectMailResponsible -BodyAsHtml $ContentMailResponsible -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
				(Get-Content -Path $PathSecurityPasswordMail | ConvertTo-SecureString -Key $KeyCrypt)) -UseSsl -ErrorAction continue
			}
		}
		# If the mode manual is active (file contains password mode manual)
		else{ # (Mode manual)
		# Commands to send mail with reports to Reponsible if mode manual is active
			Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Responsible -Port $FromMailServerPort -Subject $SubjectMailResponsible -BodyAsHtml $ContentMailResponsible -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
			(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
			while ($? -eq $false){
				write-host "WARNNING : Switch to mode manual failed in automatic mode (Bad informations in Script)" -ForegroundColor gray
				write-host "The mail has not been sended try to check if the mail address specified is correct"
				$Responsible=read-host "Specify the mail address of responsible"
				# Send mail to Responsible
				Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Responsible -Port $FromMailServerPort -Subject $SubjectMailResponsible -BodyAsHtml $ContentMailResponsible -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
				(Get-Content -Path $PathSecurityPasswordManual | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
			}
			# Command to delete the file which contains the password crypted
			Remove-Item $PathSecurityPasswordManual
		}
		write-host "The reports were sent by email if they are not received it is because the specified addresses are incorrect" -ForegroundColor green
		# Timeout between the last action and new action "Start VM"
		Timeout /t 15
		# Ask if the user want start the virtual machine created if yes started else return to the homepage
		# Initialize the variable 
		$StartVMSucces=0; $StartVMFail=0
		$ChoiceStartVM=read-host "Do you want start all virtual machines created ? [Y] for Yes, [N] for No"
		while (($ChoiceStartVM -ne $ChoiceYes) -and ($ChoiceStartVM -ne $ChoiceNo)){
			$ChoiceStartVM=read-host "Do you want start all virtual machines created ? [Y] for Yes, [N] for No"
		}
		# If choice start vm after creation is "Y" the virtual machines are turn-on
		if ($ChoiceStartVM -eq $ChoiceYes){
			write-host "MESSAGE : You have chosen to start all virtual machines" -ForegroundColor cyan
			write-host "WARNING : If you have choosen start but no virtual machines has been created, return to the homepage" -ForegroundColor yellow
			foreach ($line in $StartVMTrue) {
				# Command to start virtual machine
				Start-VM -VM $line -Confirm:$false -ErrorAction Continue
				if ($? -eq $true){
					# Variable which contains the number of virtual machine strated
					$StartVMSucces++
					write-host "Succes : The virtual machine $line has been started" -ForegroundColor green
				}
				if ($? -eq $false){
					# Variable which contains the number of virtual machine not started
					$StartVMFail++
					write-host "ERROR : The virtual machine $line has not been started check on vSphere or others issue" -ForegroundColor red
				}
			}
			# Display the message with totality of machine started or not started with warning message
			write-host "WARNING : If you don't have seen message success or error it's because the virtual machine it's already started" -ForegroundColor Yellow
			write-host "INFORMATION : $StartVMSucces virtual machines have been started and $StartVMFail not started" -ForegroundColor gray
			write-host "Exit the script in 30 seconds" -ForegroundColor Gray
			# Allows to be disconnect of server connected
			Disconnect-VIserver -server $NamevSphereServer -confirm:$false
			Timeout /t 30
			LeaveScript
		}
		# If choice start vm after creation is "N" return to the homepage
		if ($ChoiceStartVM -eq $ChoiceNo){
			write-host "MESSAGE : You have chosen to no start all virtual machines" -ForegroundColor Magenta
			write-host "Exit the script in 10 seconds" -ForegroundColor Gray
			# Allows to be disconnect of server connected
			Disconnect-VIserver -server $NamevSphereServer -confirm:$false
			Timeout /t 10
			LeaveScript
		}
	}
}

## Function LegendColors
# Allows to display a list with the color codes used in the script CreateVM
Function Legendcolors {
# Command to display a list which contains the legends of colors used by the script
	write-host "
[----------------------------------]
| > Legends of colors for messages |
|----------------------------------|"
$Succes=write-host "| Succes = Green                   |" -ForegroundColor green
$Warning=write-host "| Warning = Yellow                 |" -ForegroundColor yellow
$FailError=write-host "| Fail/Error = Red                 |" -ForegroundColor red
$YesChoice=write-host "| Choice Yes = Cyan                |" -ForegroundColor cyan
$NoChoice=write-host "| Choice No =  Magenta             | " -ForegroundColor magenta
$Information=write-host "| Information = Gray               |" -ForegroundColor gray
write-host "[----------------------------------]"
}

## Function LeaveScript
# Allows to leave the script CreateVM
Function LeaveScript {
	# Allows to leave the script with a display message and timeout
	JumpLine
	$Leavescript=Get-content -Path "$LocationScript\src\Leave.tcsrc3" -Encoding UTF8
	$Leavescript
	JumpLine
	write-host "(: ! Thanks you for using this script by Kyosuko ! Bye ! :) " -ForegroundColor green
	timeout /t 7
	exit
}

###########################################################################
##### When the script is started by the user, this is where it starts
###########################################################################

# Allows to check if the module is installed if yes importation of module PowerCLI for the executions of commands 
# else message which say install PowerCLI with option 17
# ErroractionPreference "SIlentlyContinue" allows not to display some console error messages only those indicated in the script
$CheckPowerCLI=Get-Command -Module *VMWare*
$ErrorActionPreference = "SilentlyContinue"
if ([string]::IsNullOrEmpty($CheckPowerCLI)){
	write-host "ERROR : PowerCLI is not installed" -ForegroundColor red
	try {
		# Commands to put Tls version and install module vmware and Nuget which allows find and download the module
		# PowerCLI since the "PSGallery"
		write-host 'WARNING : PowerCLI will be installed in 30 seconds it''s necessary to work if you don''t want to make the combination "Ctrl+C"' -ForegroundColor yellow
		write-host 'Not cut during the installation, please wait' -ForegroundColor yellow
		timeout /t 30
		[Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls" 
		Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -confirm:$false -ErrorAction Stop
		Set-PSRepository -Name "PSGallery" -InstallationPolicy Trusted -ErrorAction Stop
		Install-Module -Name VMware.PowerCLI -Scope CurrentUser -confirm:$false -ErrorAction Stop
	}
	catch {
		write-host "ERROR : PowerCLI has not been installed, disable policy execution script, run script in administrator or others issue try resolve it" -ForegroundColor red
		write-host "Exit the script in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		LeaveScript
	}
	# Import module PowerCLI when the script is launched and clear the console
	# Allows to ignorate certificate no valide but disable if you a certificate
	# Disable warnning message (for the next use script : restart Power Shell necessary) to join 
	# "Vmware Customer Experience" to improve program
	# Allows to display message PowerCLI, the Welcome page with date and time and begin the function "CreateVMCSV" 
	Import-Module VMware.PowerCLI
	Set-PowerCLIConfiguration -Scope User -ParticipateINCEIP $false -confirm:$false
	Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
	Clear-Host
	write-host "SUCCES : PowerCLI has been installed" -ForegroundColor green
	Timeout /t 10
	$Welcome=Get-content -Path "$LocationScript\src\Welcome.tcsrc3" -Encoding UTF8
	$Welcome
	Jumpline 
	write-host "Date and Time :" (Get-date)
	Legendcolors
	Jumpline 
	write-host "INFORMATION : Begin to the function creation of virtual machine in 10 seconds" -ForegroundColor gray
	timeout /t 10
	CreateVMCSV
}
else{
	# Import module PowerCLI when the script is launched and clear the console
	# Allows to ignorate certificate no valide but disable if you a certificate
	# Disable warnning message (for the next use script : restart Power Shell necessary) to join 
	# "Vmware Customer Experience" to improve program
	# Allows to display message PowerCLI, the Welcome page with date and time and begin the function "CreateVMCSV" 
	write-host "SUCCES : PowerCLI is already installed" -ForegroundColor green
	write-host "INFORMATION : Please wait importation of module PowerCLI" -ForegroundColor gray
	Import-Module VMware.PowerCLI
	Set-PowerCLIConfiguration -Scope User -ParticipateINCEIP $false -confirm:$false
	Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
	Clear-Host
	$Welcome=Get-content -Path "$LocationScript\src\Welcome.tcsrc3" -Encoding UTF8
	$Welcome
	Jumpline 
	write-host "Date and Time :" (Get-date)
	Jumpline
	Legendcolors
	Jumpline 
	write-host "INFORMATION : Begin to the function creation of virtual machine in 10 seconds" -ForegroundColor gray
	timeout /t 10
	CreateVMCSV
}
#[###########################################################################]
#[############################# By Kyosuko v1.0 #############################]
#[###########################################################################]
#[############################ To Mr "xx" ###################################]            
#[###########################################################################]