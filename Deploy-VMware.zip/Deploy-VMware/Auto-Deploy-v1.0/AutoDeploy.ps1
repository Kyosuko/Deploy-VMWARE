##########################################################################
##                                                                      ##
##                          Version : 1.0                               ##
##                    Created by : Kyosuko                              ##
##                      Recipient : xx                                  ##							![Also sorry to my bad way to write english.]!
##                     Release Date : 20/11/2020                        ##							![Also sorry to my bad way to write english.]!
##                      Name : AutoDeploy.ps1                           ##
##                                                                      ##
##########################################################################
#####(0) First part  of script - Functions used by the script ############
##########################################################################

## Variables used which allows to be used by all functions
$script:ChoiceYes="Y" # When the user have a choice allows to say condition equal to "Y"
$script:ChoiceNo="N" # When the user have a choice allows to say condition equal to "N"
$script:LocationScript=Get-Location # Allows to get a location where is launched the script and search the sources used by the script in the folder /src and /data
$script:PathSecurityPassword="$LocationScript\data\tmp.tcsrc3" # Allows to known where must be save the file contained the password crypted
$script:JumpHTML="<p/>" # Allows to Jump a line in the code HTML specialy for technician mails
$script:Delimiter=";" # Allows to define the delimiter which must be used in the CSV file to be read correctly

###########################################################################s
##### List of functions
###########################################################################

## Function JumpLine
# Allows to Jump a line without use ` or another chain of character empty
Function Jumpline {
	# Put an empty string to jumpline
	""
}

## Function CreateVMCSV
# Allows to create many virtual machines since a CSV File and purpose the choice
# to start vm after creation also send mail with reports
Function CreateVMCSV {
	# Ask the user to specify the location of the CSV containing the parameters of the VM
	write-host "You want create virtual machines since a CSV file" -ForegroundColor gray
	write-host 'WARNING : The delimiter in the CSV file must be ";" in order to be able to create virtual machines' -ForegroundColor yellow
	$LocationCSV=read-host 'Specify the location of CSV file "Exemple : (C:/windows/Kyosuko.csv)"'
	# Check if the CSV file exists with the extension .csv
	$CheckLocationCSV=Get-Item $LocationCSV ; $CheckLocationCSV.Extension
	# If the file exists, a message, success and warning is displayed
	if ($CheckLocationCSV.Extension -eq ".csv") {
    	write-host "SUCCES : The file specifed exist with the good extension .csv" -ForegroundColor green
    	write-host 'WARNING : If you don''t use the delimiter ";" in the CSV file you must change else not working correctly'  -ForegroundColor yellow
	}
	# As long as the file specified in the $LocationCSV variable is not a csv file, a new entry is displayed with an error message
	While ($CheckLocationCSV.Extension -ne ".csv") {
		write-host 'ERROR : The file than you have specify is not valide check if it''s the good path or if there are the extension ".csv"' -ForegroundColor red
		$LocationCSV=read-host 'Specify the location of CSV file "Exemple : (C:/windows/Kyosuko.csv)"'
		$CheckLocationCSV=Get-Item $LocationCSV ; $CheckLocationCSV.Extension
		# If the file exists, a message, success and warning is displayed
		if ($CheckLocationCSV.Extension -eq ".csv") {
    		write-host "SUCCES : The file specifed exist with the good extension .csv" -ForegroundColor green
    		write-host 'WARNING : If you don''t use the delimiter ";" in the CSV file you must change else not working correctly'  -ForegroundColor yellow
		}
	}
	# Check than for the first line there are a delimiter ";"
	# A timeout between the last action the new 
	timeout /t 5
	$CheckDelimiter=Get-content $LocationCSV | Select -First 1
	if ($CheckDelimiter -like "*;*"){
		write-host 'SUCCES : The delimiter used is ";"' -ForegroundColor Green
	}
	else {
		write-host 'ERROR : You don''use the delimiter ";" please use it and retry' -ForegroundColor red
		write-host "Return to the homepage in 30 seconds" -ForegroundColor Gray
	}
	# A timeout between the last action the new then importation the CSV file and display message success, information and warning
	# Also a message with version PowerShell is displayed
	timeout /t 5
	Import-CSV -Path $LocationCSV -Delimiter $Delimiter | Format-table
	write-host "SUCCES : Import successful" -ForegroundColor green
	write-host "WARNING : If you not see correctly the table with the values it's because the file is empty or you don't use the good delimiter so solve this problem else problem during creation VMs" -ForegroundColor yellow
	timeout /t 5
	JumpLine
	write-host 'WARNING : To use Power CLI you must have a version PowerShell "5" at least if this is not the case `
upgrade to continue, otherwise the utility will not work properly' -ForegroundColor yellow
	write-host "INFORMATION : Your PowerShell version is as follows :" $PSVersionTable.PSVersion.Major -ForegroundColor gray
	# A check of version PowerShell is "5" or upper and if it's okay display message success else a error message and propose 
	# if he want upgrade PowerShell a message display how to upgrade else return to the homepage
	if ((($Host.Version.Major) -eq 5) -or (($Host.Version.Major)-gt [int]5)) {
		Write-host 'SUCCES : You have version "5" it''s okay' -ForegroundColor green
	}
	else {
    	write-host 'ERROR : You don''t have version "5", please upgrade your PS' -ForegroundColor red
		$ChoicePS=read-host "Do you want upgrade you Power-Shell to the last Version ? [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
		if ($ChoicePS -eq $ChoiceYes){
			write-host "MESSAGE : You have chosen to upgrade PowerShell" -ForegroundColor cyan
			write-host "INFORMATION : To Upgrade you power-shell you must download minimum .NetFramwork 4.5 and WMF 5.0 (With KB)" -ForegroundColor gray
			write-host "INFORMATION : Or download minimum .NetFramwork 4.5 and install with msi" -ForegroundColor gray
			write-host "Return to the homepage in 30 seconds" -ForegroundColor Gray
			Timeout /t 30
			return
    	}
		elseif ($ChoicePS -eq $ChoiceNo){
    		write-host "MESSAGE : You have chosen to not installed the PowerShell, try resolve the issue" -ForegroundColor Magenta
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
		# As long as the choice is not Y or N the question is reasked if he want upgrade PowerShell and after choice
		# if he want upgrade PowerShell a message display how to upgrade else return to the homepage
		while (($ChoicePS -ne $ChoiceYes) -and ($ChoicePS -ne $ChoiceNo)){
   			$ChoicePS=read-host "Do you want upgrade PowerShell? [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
			if ($ChoicePS -eq $ChoiceYes){
				write-host "MESSAGE : You have chosen to upgrade PowerShell" -ForegroundColor cyan
				write-host "INFORMATION : To Upgrade you power-shell you must download minimum .NetFramwork 4.5 and WMF 5.0 (With KB)" -ForegroundColor gray
				write-host "INFORMATION : Or download minimum .NetFramwork 4.5 and install with msi" -ForegroundColor gray
				write-host "Return to the homepage in 30 seconds" -ForegroundColor Gray
				Timeout /t 30
				return
			}
			elseif ($ChoicePS -eq $ChoiceNo){
				write-host "MESSAGE : You have chosen to not installed the PowerShell, try resolve the issue" -ForegroundColor Magenta
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
			}
		}
	}
	# A timeout between the last action the next action "PowerCLI"
	timeout /t 5
	JumpLine
	# A check if PowerCLI is installed it's good display a message success else asked if choice yes it install else return
	# to homepage
	write-host "WARNING : To use PowerCLI you must have the module installed" -ForegroundColor yellow
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not installed" -ForegroundColor red
		$ChoicePC=read-host "Do you want install PowerCLI ? [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
	}
	else{
		$ChoicePC="Installed"
		write-host "SUCCES : PowerCLI is already installed" -ForegroundColor green
	}
	if ($ChoicePC -eq $ChoiceYes){
		try {
			# Commands to put Tls version and install module vmware and Nuget which allows find and download the module
			# PowerCLI since the "PSGallery"
			write-host "MESSAGE : You have chosen to install PowerCLI" -ForegroundColor cyan
			write-host 'Not cut during the installation, please wait' -ForegroundColor yellow
			[Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls" 
			Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -confirm:$false -ErrorAction Stop
			Set-PSRepository -Name "PSGallery" -InstallationPolicy Trusted -ErrorAction Stop
			Install-Module -Name VMware.PowerCLI -Scope CurrentUser -confirm:$false -ErrorAction Stop
		}
		catch {
			write-host "ERROR : PowerCLI has not been installed, try resolve this issue" -ForegroundColor red
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
		finally {
			write-host "INFORMATION : Please wait importation of module PowerCLI" -ForegroundColor gray
			Import-Module VMware.PowerCLI
			Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
			write-host "SUCCES : PowerCLI has been installed" -ForegroundColor green
		}
	}
	elseif ($ChoicePC -eq $ChoiceNo){
		write-host "MESSAGE : You have chosen to not install PowerCLI, try resolve this issue" -ForegroundColor Magenta
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# As long as the choice is not Y,N or already installed the question is reasked if he want install PowerCLI and after choice
	# if it's yes it install else return to the homepage
	while (($ChoicePC -ne $ChoiceYes) -and ($ChoicePC -ne $ChoiceNo) -and ($ChoicePC -ne "Installed")){
		$ChoicePC=read-host "Do you want install PowerCLI ? [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
		if ($ChoicePC -eq $ChoiceYes){
			try {
				# Commands to put Tls version and install module vmware and Nuget which allows find and download the module
				# PowerCLI since the "PSGallery"
				write-host "MESSAGE : You have chosen to install PowerCLI" -ForegroundColor cyan
				write-host 'Not cut during the installation, please wait' -ForegroundColor yellow
				[Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls" 
				Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -confirm:$false -ErrorAction Stop
				Set-PSRepository -Name "PSGallery" -InstallationPolicy Trusted -ErrorAction Stop
				Install-Module -Name VMware.PowerCLI -Scope CurrentUser -confirm:$false -ErrorAction Stop
			}
			catch {
				write-host "ERROR : PowerCLI has not been installed, try resolve this issue" -ForegroundColor red
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
			}
			finally {
				# Import module PowerCLI 
				# Allows to ignorate certificate no valide but disable if you a certificate
				Import-Module VMware.PowerCLI
				Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
				write-host "SUCCES : PowerCLI has been installed" -ForegroundColor green
			}
		}
		elseif ($ChoicePC -eq $ChoiceNo){
			write-host "MESSAGE : You have chosen to not install PowerCLI, try resolve the issue" -ForegroundColor Magenta
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
	}
	# A timeout between the last action the next action "connect vSphere" and display message warning
	timeout /t 5
	JumpLine
	write-host "INFORMATION : Now you are able to connect to vSphere for creation of VMs" -ForegroundColor gray
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validate, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			# Remove the file which contains the password crypted
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validate, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
	# Allows to count the number of line without the first and spaces and got the number of virtual machines than
	# the user want create
	$CheckNBVM=Get-content $LocationCSV | Where-Object { $_ } | Measure-Object
	$NBVM=$CheckNBVM.count-1
	# Allows to count the number of delimiter ";" and find if there are are error (Ex : Not same number of parameter for each line)
	# If it's good display count the totality of virtual machines the user want create else error message display and return to the homepage
	[int]$CutLast = $Null 
	Get-Content $LocationCSV | ? {$_} | % {
	if($CutLast -and !($_.split(";").count -eq $CutLast)){
		write-host"ERROR : ! There is a problem on the line $($_.psobject.Properties.value[5]) of the CSV file incorrect number of parameters`
		compared to others ! Try resolve this issue" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	elseif (!$CutLast){
		$CutLast = $_.split(";").count
		}
	}
	# Display the number of virtual machines asked to create and number of parameters with timeout between this action and ask continue
	write-host "INFORMATION : There are " $NBVM "virtual machines that will be create" -ForegroundColor gray
	write-host "INFORMATION : These virtual machines will be created with $CutLast settings" -ForegroundColor gray
	timeout /t 10
	# Ask if the user want continue after the last informations gived
	$Askcontinue=read-host "Do you want continue ? [Y] for Yes, [N] for No"
	# As long as the choice is not Y or N the question is reasked and after choice if it's yes it continue else return to the homepage
	while ($Askcontinue -ne $ChoiceYes -and ($AskContinue -ne $ChoiceNo)){
		$Askcontinue=read-host "Do you want continue ? [Y] for Yes, [N] for No"
	}
	if ($AskContinue -eq $ChoiceNo) {
		write-host "MESSAGE : You have chosen to not continue" -ForegroundColor Magenta
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	elseif ($AskContinue -eq $ChoiceYes) {
		write-host "MESSAGE : You have chosen to continue" -ForegroundColor Cyan
	}
	# Import the CSV file without format table 
	$PathCSVFormatNoTable=Import-CSV $LocationCSV -Delimiter $Delimiter 
	# Ask if the user want import ISO file which will be used to connect this on the virtual machines create after
	$Askimport=read-host "Do you want import iso file in datastore ? [Y] for Yes, [N] for No"
	# As long as the choice is not Y or N the question is reasked and after choice if it's yes purpose to fill the fields else continue
	while ($Askimport -ne $ChoiceYes -and ($Askimport -ne $ChoiceNo)){
		$Askimport=read-host "Do you want import iso file in datastore [Y] for Yes, [N] for No"
	}
	if ($Askimport -eq $ChoiceNo) {
		write-host "MESSAGE : You have chosen to not import iso file in datastore" -ForegroundColor Magenta
	}
	elseif ($Askimport -eq $ChoiceYes) {
		write-host "MESSAGE : You have chosen to import iso file in datastore" -ForegroundColor Cyan
		$LocationISO=read-host 'Specify the location of ISO file "Exemple : (C:/windows/Kyosuko.iso)"'
		$CheckLocationISO=Get-Item $LocationISO ; $CheckLocationISO.Extension
		# As long as the file has not extension .iso the input field is asked to fill the field with good path
		While ($CheckLocationISO.Extension -ne ".iso") {
    		write-host 'ERROR : The file than you have specify is not valide check if it''s the good path or if there are the extension ".iso"' -ForegroundColor red
    		$LocationISO=read-host 'Specify the location of ISO file "Exemple : (C:/windows/Kyosuko.iso)"'
    		$CheckLocationISO=Get-Item $LocationISO; $CheckLocationISO.Extension
    		if ($CheckLocationISO.Extension -eq ".iso") {
        		write-host "SUCCES : The file specifed exist with the good extension .iso" -ForegroundColor green
    		}
		}
		# Ask to the user specify the name of datacenter of respect the case sensitivity and it's okay display a success message
		write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
		$LocationDatacenter=read-host 'Specify the datacenter you want import the ISO file "Exemple : Datacenter"'
		# As long as the field is empty the input field is asked with error and warning message else it's okay display a success message
		while ([string]::IsNullOrEmpty($LocationDatacenter)){
			write-host "ERROR : Please fill all fields, good name or others issue" -ForegroundColor red
			write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
    		$LocationDatacenter=read-host 'Specify the Datacenter you want import the ISO file "Exemple : Datacenter"'
		}
		# Command to check if the name of datacenter specified exists and it's yes print success message
		$CheckDatacenter=Get-Datacenter $LocationDatacenter
		if ($? -eq $true) {
			write-host "SUCCESS : The datacenter entered will be used" -ForegroundColor green
		}
		# As long as the name entered is not good the input field is asked with error and warning message else it's okay display a success message
		While ($?-eq $false) {
			write-host 'ERROR : The datacenter you have specify is not valide check if it''s the good name' -ForegroundColor red
			write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
			   $LocationDatacenter=read-host 'Specify the datacenter you want import the ISO file "Exemple : Datacenter"'
			# As long as the field is empty the input field is asked with error and warning message else it's okay display a success message
    		while ([string]::IsNullOrEmpty($LocationDatacenter)){
				write-host "ERROR : Please fill all fields, good name or others issue" -ForegroundColor red
				write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
        		$LocationDatacenter=read-host 'Specify the datacenter you want import the ISO file "Exemple : Datacenter"'
			}
			# Command to check if the name of datacenter specified exists and it's yes print success message
    		$CheckDatacenter=Get-Datacenter $LocationDatacenter
    		if ($? -eq $true) {
        		write-host "SUCCESS : The datacenter entered will be used" -ForegroundColor green
    		}
		}
		# Ask to the user specify the name of datastore of respect the case sensitivity and it's okay display a succes message
		write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
		$LocationDatastore=read-host 'Specify the datastore you want import the ISO file "Exemple : KyosukoC2"'
		# As long as the field is empty the input field is asked with error and warning message else it's okay display a succes message
		while ([string]::IsNullOrEmpty($LocationDatastore)){
			write-host "ERROR : Please fill all fields, good name or others issue" -ForegroundColor red
			write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
    		$LocationDatastore=read-host 'Specify the datastore you want import the ISO file "Exemple : KyosukoC2"'
		}
		# Command to check if the name of datastore specified exists and it's yes print success message
		$CheckDatastore=Get-Datastore $LocationDatastore
		if ($? -eq $true) {
			write-host "SUCCESS : The datastore entered will be used" -ForegroundColor green
		}
		# As long as the name entered is not good the input field is asked with error and warning message else it's okay display a success message
		While ($?-eq $false) {
			write-host 'ERROR : The datastore you have specify is not valide check if it''s the good name' -ForegroundColor red
			write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
			$LocationDatastore=read-host 'Specify the datastore you want import the ISOfile "Exemple : KyosukoC2"'
			# As long as the field is empty the input field is asked with error and warning message else it's okay display a success message
    		while ([string]::IsNullOrEmpty($LocationDatastore)){
				write-host "ERROR : Please fill all fields, good name or others issue" -ForegroundColor red
				write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
        		$LocationDatastore=read-host 'Specify the datastore you want import the ISO file "Exemple : KyosukoC2"'
			}
			# Command to check if the name of datastore specified exists and it's yes print success message
    		$CheckDatastore=Get-Datastore $LocationDatastore
    		if ($? -eq $true) {
				write-host "SUCCESS : The datastore entered will be used" -ForegroundColor green
    		}
		}
		write-host "WARNING : Please, not cut during the upload of iso file on datastore" -ForegroundColor yellow
		# Command to copy the iso file in the datastore
		Copy-DatastoreItem -Item "$LocationISO" -Destination "vmstore:\$LocationDatacenter\$LocationDatastore" 
		# If the copy has been effectuated display a message success
		if ($? -eq $true){
    		write-host "SUCCESS : The iso file has been imported in the datastore $LocationDatastore" -ForegroundColor green
		}
		# If the attempt of copy the iso in datastore has failed a message asked if the user want continue if yes it continue else return to the homepage
		elseif ($? -eq $false){
    		write-host "ERROR : The iso file has not been imported in the datastore $LocationDatastore, check the case senstivity or others issue" -ForegroundColor red
			$Askcontinue=read-host "Do you want continue ? [Y] for Yes, [N] for No"
			# As long as the choice is not Y or N the question is reasked and after choice if it's yes it continue else return to the homepage
    		while ($Askcontinue -ne $ChoiceYes -and ($AskContinue -ne $ChoiceNo)){
        	$Askcontinue=read-host "Do you want continue ? [Y] for Yes, [N] for No"
    		}
    		if ($AskContinue -eq $ChoiceNo) {
        		write-host "MESSAGE : You have chosen to not continue" -ForegroundColor Magenta
        		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
        		Timeout /t 10
        		return
 			}  
    		elseif ($AskContinue -eq $ChoiceYes) {
				write-host "MESSAGE : You have chosen to continue" -ForegroundColor Cyan
			}
		}
	}
	# Ask to the user if he want send the reports by mail after creation of virtual machine
	$Askreports=read-host "Do you want send the reports by mail after creation of virtual machines ?`
[Y] for Yes, [N] for No"
	# As long as the choice is not Y or N the question is reasked 
	while ($Askreports -ne $ChoiceYes -and ($Askreports -ne $ChoiceNo)){
		$Askreports=read-host "Do you want send the reports by mail after creation of virtual machines ? `
[Y] for Yes, [N] for No"
	}
	if ($Askreports -eq $ChoiceNo) {
		write-host "MESSAGE : You have chosen not send the reports by mail" -ForegroundColor Magenta
	}
	elseif ($Askreports -eq $ChoiceYes) {
		write-host "MESSAGE : You have chosen send the reports by mail" -ForegroundColor Cyan
	}
	# If the choice to send reports has not been selected the creation of the virtual machines will be make without reports
	if ($Askreports -eq $ChoiceNo){
		write-host "WARNING : Creation of virtual machines in 10 seconds" -ForegroundColor Yellow
		timeout /t 10
		# Initialize the variable 
		$CreateVMSucces=0;$CreateVMFail=0;$CreateVMCancel=0
		$StartVMTrue=$null;$IsoVMTrue=$null
		foreach ($line in $PathCSVFormatNoTable){
		# Condition check if the line respect the limitations about size{
			if (($line.NumCPU -le 2) -and ($line.MemoryMB -le 1572) -and ($line.DiskMB -le 125) -and ($line.DiskStorageFormat -eq "thick") -or ($line.DiskStorageFormat -eq "thin")){
				# Command to create virtual machine
				New-VM -VMHost $line.VMHost -Name $line.Name -Datastore $line.Datastore -ResourcePool $line.RessourcePool -NumCPU $line.NumCPU -MemoryMB $line.MemoryMB -DiskMB $line.DiskMB -DiskStorageFormat $line.DiskStorageFormat -CD -Floppy -Confirm:$false
				if ($? -eq $true){
					# Variable which contains the number of virtual machine created
					$CreateVMSucces++
					# Variable which contains the name of virtual machine created for the choice if the user want started the vms after creation
					$StartVMTrue +=, $line.Name 
					# Variable which contains the name of virtual machine created for the choice if the user want connect theiso imported after creation
					$IsoVMTrue +=, $line.Name 
					Write-Host "SUCCES : The virtual machine" $line.Name "has been created with success" -ForegroundColor green
				}
				elseif($? -eq $false){
					# Variable which contains the number of virtual machine badly created/not created
					$CreateVMFail++
					Write-Host "ERROR : The virtual machine" $line.Name " has not been created or not created correctly because exists already or others issue" -ForegroundColor red
				}
			}
			# Cancel the creation of virtual machine if the line not respect the limitations about size
			elseif (($line.NumCPU -gt 2) -or ($line.MemoryMB -gt 1572) -or ($line.DiskMB -gt 125) -or ($line.DiskStorageFormat -ne "thick") -and ($line.DiskStorageFormat -ne "thin")){
				# Variable which contains the number of virtual machine canceled
				$CreateVMCancel++
				write-host "The virtual machine $($line.name) has been canceled not respect the limitations about size" -ForegroundColor Magenta
			}
		}
		# Display the message with totality of machine created or not created
		write-host "INFORMATION : $CreateVMSucces virtual machines have been created and $CreateVMFail not created/correctly with error and $CreateVMCancel canceled" -ForegroundColor gray
		Timeout /t 10
		# Ask if the user want connect the iso filed which has been imported before
		$AskconnectISO=read-host "Do you want connect the ISO imported with the virtual machines ? [Y] for Yes, [N] for No"
		# As long as the choice is not Y or N the question is reasked 
		while ($AskconnectISO -ne $ChoiceYes -and ($AskconnectISO -ne $ChoiceNo)){
    		$AskconnectISO=read-host "Do you want connect the ISO imported with the virtual machines ? [Y] for Yes, [N] for No"
		}
		if ($AskconnectISO -eq $ChoiceNo) {
    		write-host "MESSAGE : You have chosen not connect the iso file imported" -ForegroundColor Magenta
		}
		# If choice yes is selected link of virtual machines with iso
		elseif ($AskconnectISO -eq $ChoiceYes) {
			write-host "MESSAGE : You have chosen connect the iso file imported" -ForegroundColor Cyan
			write-host "WARNING : Connection iso file on virtual machines in 10 seconds" -ForegroundColor Yellow
			timeout /t 10
			# Allows to delete everythings after the last "\" from the path specified when the iso file has been imported
			# Initialize the variable 
			$IsoVMVMSucces=$null;$IsoVMVMFail=$null
    		$LastAntiSlash = $LocationISO.LastIndexOf("\")
    		$NameISO = $LocationISO.Substring($LastAntiSlash+1)
    		foreach ($line in $IsoVMTrue) {
				# Command to get the virtual machine then cd player and define the iso with option "Start connected turn on"
        		Get-VM -Name $line | Get-CDDrive | Set-CDDrive -StartConnected $true -IsoPath "[$LocationDatastore] $NameISO" -confirm:$false
        		if ($? -eq $true){
					# Variable which contains the number of virtual machine connected the iso with succes
           			$IsoVMVMSucces++
            		write-host "Succes : The virtual machine $line has been connected with iso file" -ForegroundColor green
        		}
        		elseif ($? -eq $false){
					# Variable which contains the number of virtual machine connected the iso with fail
            		$IsoVMVMFail++
            		write-host "ERROR : The virtual machine $line has not been connected with iso file" -ForegroundColor red
        		}
			}
		# Display the message with totality of machine connected or not connected with the iso file
		write-host "INFORMATION : $IsoVMVMSucces virtual machines are been connected with iso and $IsoVMVMFail not connected" -ForegroundColor gray
		}
		# A timeout between the last action the next action "StartVM"
		Timeout /t 10
		# Ask if the user want start the virtual machine created if yes started else return to the homepage
		# Initialize the variable 
		$StartVMSucces=0; $StartVMFail=0
		$ChoiceStartVM=read-host "Do you want start all virtual machines created ? [Y] for Yes, [N] for No"
		while (($ChoiceStartVM -ne $ChoiceYes) -and ($ChoiceStartVM -ne $ChoiceNo)){
			$ChoiceStartVM=read-host "Do you want start all virtual machines created ? [Y] for Yes, [N] for No"
		}
		if ($ChoiceStartVM -eq $ChoiceYes){
			write-host "MESSAGE : You have chosen to start all virtual machines" -ForegroundColor cyan
			write-host "WARNING : If you have choosen start but no virtual machines has been created, return to the homepage" -ForegroundColor yellow
			foreach ($line in $StartVMTrue) {
				# Command to start virtual machine
				Start-VM -VM $line -Confirm:$false -ErrorAction Continue
				if ($? -eq $true){
					# Variable which contains the number of virtual machine strated
					$StartVMSucces++
					write-host "Succes : The virtual machine $line has been started" -ForegroundColor green
				}
				elseif ($? -eq $false){
					# Variable which contains the number of virtual machine not started
					$StartVMFail++
					write-host "ERROR : The virtual machine $line has not been started not exists, already started or others issue" -ForegroundColor red
				}
			}
			# Display the message with totality of machine started or not started with warning message
			write-host "WARNING : If you don't have seen message success or error it's because the virtual machine it's already started" -ForegroundColor Yellow
			write-host "INFORMATION : $StartVMSucces virtual machines have been started and $StartVMFail not started" -ForegroundColor gray
			write-host "Return to the homepage in 30 seconds" -ForegroundColor Gray
			Timeout /t 30
			return
		}
		elseif ($ChoiceStartVM -eq $ChoiceNo){
			write-host "MESSAGE : You have chosen to no start all virtual machines" -ForegroundColor Magenta
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
	}

	# If the choice to send reports has been selected the creation of the virtual machines will be make with reports
	if ($Askreports -eq $ChoiceYes){
		# Check if Telnet is installed to tester to connection between server mail
		write-host "WARNING : To send emails telnet is required to do a connection test" -ForegroundColor yellow
		# Commands to check if telnet is installed and get the version of Windows (Server, Workstation)
		$CheckTelnet=get-command -name *telnet*
		$CheckVersionWindows=Get-WmiObject Win32_OperatingSystem | Select-Object "Caption" 
		$GetCheckVersionWindows=$CheckVersionWindows.caption
		if ([string]::IsNullOrEmpty($CheckTelnet)){
			write-host "ERROR : Telnet is not installed" -ForegroundColor red
			$ChoiceTelnet=read-host "Do you want install Telnet [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
		}
		else{
			$ChoiceTelnet="Installed"
			write-host "SUCCES : Telnet is already installed" -ForegroundColor green
		}
		# If the version Windows contains the word "Server" (Windows Server) and choice installation telnet is "Y" so installation of functionality Telnet
		# by Dism
		if (($ChoiceTelnet -eq $ChoiceYes) -and ($GetCheckVersionWindows -notlike "*Server*")){
			try {
				write-host "MESSAGE : You have chosen to install Telnet" -ForegroundColor cyan
				dism /Online /Enable-Feature /featurename:TelnetClient -ErrorAction Stop
			}
			catch {
				write-host "ERROR : Telnet has not been installed, try resolve this issue" -ForegroundColor red
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
			}
			finally {
				write-host "SUCCES : Telnet has been installed" -ForegroundColor green
			}
		}
		# If the version Windows contains not the word "Server" (Windows Workstation) and choice installation telnet is "Y" so installation of functionality Telnet
		# by WindowsFeature
		elseif (($ChoiceTelnet -eq $ChoiceYes) -and ($GetCheckVersionWindows -like "*Server*")){
			try {
				write-host "MESSAGE : You have chosen to install Telnet" -ForegroundColor cyan
				Install-WindowsFeature Telnet-Client -ErrorAction Stop
			}
			catch {
				write-host "ERROR : Telnet has not been installed, try resolve this issue" -ForegroundColor red
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
			}
			finally {
				write-host "SUCCES : Telnet has been installed" -ForegroundColor green
			}
		}
		elseif ($ChoiceTelnet -eq $ChoiceNo){
			write-host "MESSAGE : You have chosen to not install Telnet, try resolve this issue to create virtual machines with send mails" -ForegroundColor Magenta
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
		# As long as the choice is not Y, N ro already installed the question is reasked 
		while (($ChoiceTelnet -ne $ChoiceYes) -and ($ChoiceTelnet -ne $ChoiceNo) -and ($ChoiceTelnet -ne "Installed")){
			$ChoiceTelnet=read-host "Do you want installed Telnet ? [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
			if (($ChoiceTelnet -eq $ChoiceYes) -and ($GetCheckVersionWindows -notlike "*Server*")){
				try {
					write-host "MESSAGE : You have chosen to installed Telnet" -ForegroundColor cyan
					Install-WindowsFeature Telnet-Client -ErrorAction Stop
				}
				catch {
					write-host "ERROR : Telnet has not been installed, try resolve this issue" -ForegroundColor red
					write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
					Timeout /t 10
					return
				}
				finally {
					write-host "SUCCES : Telnet has been installed" -ForegroundColor green
				}
			}
			elseif (($ChoiceTelnet -eq $ChoiceYes) -and ($GetCheckVersionWindows -like "*Server*")){
				try {
					write-host "MESSAGE : You have chosen to installed Telnet" -ForegroundColor cyan
					dism /Online /Enable-Feature /featurename:TelnetClient -ErrorAction Stop
				}
				catch {
					write-host "ERROR : Telnet has not been installed, try resolve this issue" -ForegroundColor red
					write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
					Timeout /t 10
					return
				}
				finally {
					write-host "SUCCES : Telnet has been installed" -ForegroundColor green
				}
			}
			# If the choice installation TelNet is "N" return to home page
			elseif ($ChoiceTelnet -eq $ChoiceNo){
				write-host "MESSAGE : You have chosen to not install Telnet it's necessary, try resolve the issue" -ForegroundColor Magenta
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
			}
		}
		# Ask the user to specify the credentials of mail server to test send mail and they will be used for send the reports if work
		write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
		$FromMailServer = read-host "Specify the mail server address of sender" 
		$FromMailServerPort = read-host "Specify the port of mail server"
		# As long as than the fields is empty the fills are reasked
		while (([string]::IsNullOrEmpty($FromMailServerPort)) -or ([string]::IsNullOrEmpty($FromMailServer))) {
			write-host "ERROR : All fields must be filled" -ForegroundColor red
			write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
			$FromMailServer=read-host "Specify the mail server address of sender" 
			[int]$FromMailServerPort=read-host "Specify the port of mail server"
		}
		try{
		# Command to test the connection of server mail via Telnet
		$Testconnection=Test-NetConnection $FromMailServer -port $FromMailServerPort 
		# As long as than the test connection fail the fills are reasked
		while ($Testconnection.tcptestsucceeded -eq $false){
			write-host "ERROR : The connection has not been etablished bad informations used, server state or others retry" -ForegroundColor red
			write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
			$FromMailServer=read-host "Specify the mail server address of sender" 
			[int]$FromMailServerPort=read-host "Specify the port of mail server"
			# As long as than the fields is empty the fills are reasked
			while (([string]::IsNullOrEmpty($FromMailServerPort)) -or ([string]::IsNullOrEmpty($FromMailServer))) {
				write-host "ERROR : All fields must be filled" -ForegroundColor red
				write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
				$FromMailServer=read-host "Specify the mail server address of sender" 
				[int]$FromMailServerPort=read-host "Specify the port of mail server"
				}
			# Command to test the connection of server mail via Telnet
			$Testconnection=Test-NetConnection $FromMailServer -port $FromMailServerPort     
			}
		}
		catch{
			# If the test connection fail the fills are reasked
			write-host "ERROR : The connection has not been etablished bad informations used, server state or others retry" -ForegroundColor red
			write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
			$FromMailServer=read-host "Specify the mail server address of sender" 
			[int]$FromMailServerPort=read-host "Specify the port of mail server"  
			# As long as than the fields is empty the fills are reasked
			while (([string]::IsNullOrEmpty($FromMailServerPort)) -or ([string]::IsNullOrEmpty($FromMailServer))) {
				write-host "ERROR : All fields must be filled else connection " -ForegroundColor red
				write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
				$FromMailServer=read-host "Specify the mail server address of sender" 
				[int]$FromMailServerPort=read-host "Specify the port of mail server"
			}
			# Command to test the connection of server mail via Telnet
			$Testconnection=Test-NetConnection $FromMailServer -port $FromMailServerPort 
		}
		# If the command to test the connection of server mail has worked display a message success
		if ($Testconnection.tcptestsucceeded -eq $true){
			Write-Host "SUCCES : The connection has been established" -ForegroundColor green
		}
		# If the command to test the connection of server mail is always fail display a message error and return to the homepage
		elseif ($? -eq $false){
			write-host "ERROR : Despite your two attempts, this did not work empty field, bad informations used, server state or others retry later" -ForegroundColor red
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}	
		# Email address that will be used to receive the test sending email
		write-host "WARNING : To send report by mail a test send mail will be make" -ForegroundColor yellow
		$MailEncodage="UTF8" 
		$MailTest="Kyosukoxxx@gmail.com"
		$SubjectMailTest="Do not Reply : Send mail test about creation of VM"
		$ContentMailTest="Hey, if you receive this mail it's because the send mail work with the credentials"
		try{
			# Specify the e-mail address and password that will be used to send the report
			$FromMailUserMail=read-host "Specify the mail address of sender" 
			read-host "Specify the password of mail address to sender" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -ErrorAction stop -confirm:$false 
			# As long as than the fields is empty the fills are reasked 
			while ([string]::IsNullOrEmpty($FromMailUserMail)) {
				write-host "ERROR : All fields must be filled" -ForegroundColor red
				$FromMailUserMail=read-host "Specify the mail address of sender" 
				read-host "Specify the password of mail address to sender" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -ErrorAction stop -confirm:$false 
			}
			# Allows to specify the mail the "from" in the mail
			$Mailaddressfrom=$FromMailUserMail
			# Command to send mail test
			Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $MailTest -Port $FromMailServerPort -Subject $SubjectMailTest -Body $ContentMailTest -BodyAsHtml -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction Stop
		}
		catch{
			# If the command send mail test has not worked the user must specify the e-mail address and password that will be used to send the report 
			write-host "ERROR : All fields must be filled or the send mail has not worked, try yet" -ForegroundColor red
			$FromMailUserMail=read-host "Specify the mail address of sender" 
			read-host "Specify the password of mail address to sender" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -ErrorAction stop -confirm:$false 
			# As long as than the fields is empty the fills are reasked 
			while ([string]::IsNullOrEmpty($FromMailUserMail)) {
				write-host "ERROR : All fields must be filled" -ForegroundColor red
				$FromMailUserMail=read-host "Specify the mail address of sender" 
				read-host "Specify the password of mail address to sender" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -ErrorAction stop -confirm:$false 
			}
			# Allows to specify the mail the "from" in the mail
			$Mailaddressfrom=$FromMailUserMail
			# Command to send mail test
			Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $MailTest -Port $FromMailServerPort -Subject $SubjectMailTest -Body $ContentMailTest -BodyAsHtml -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
		}
		# If the send mail test has worked display a message succes
		if ($? -eq $true){
			Write-Host "SUCCES : The send mail test has worked " -ForegroundColor green
		}
		# If the send mail test has not worked display a message error and delete the file which contains the password crypted
		elseif ($? -eq $false){
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Despite your two attempts, this did not work empty field, bad informations used, server state or others retry later" -ForegroundColor red
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
		# Ask the user to put the addresses mail of recipients
		write-host "WARNING : The addresses mail entered will be used like recipients" -ForegroundColor yellow
		$Technician=read-host "Specify the mail address of technician"
		$Applicant=read-host "Specify the mail address of applicant"
		$Responsible=read-host "Specify the mail address of responsible"
		# As long as than the fields is empty the fills are reasked 
		while (([string]::IsNullOrEmpty($Technician)) -or ([string]::IsNullOrEmpty($Applicant)) -or ([string]::IsNullOrEmpty($Responsible))){
			write-host "ERROR : An error occurred, please complete all fields" -ForegroundColor red
			$Technician=read-host "Specify the mail address of technician"
			$Applicant=read-host "Specify the mail address of applicant"
			$Responsible=read-host "Specify the mail address of responsible"
		}
		# Display a message creation of virtual machine with timeout
		write-host "WARNING : Creation of virtual machines in 10 seconds" -ForegroundColor Yellow
		timeout /t 10
		# Declaration of variables container the numbers of creation vm success, fail, cancel and a pourcentage also a pourcentage for the gauge in the mail (CSS).
		# Commands to recup only the beginning of address mail before "@"
		# Initialize the variable 
		$CreateVMSucces=0;$CreateVMFail=0;$CreateVMCancel=0
		$StartVMTrue=$null;$IsoVMTrue=$null
		$PourcentCreateVMSucces=0;$PourcentCreateVMSuccesCSS=0;$HTMLVMSucces=0
		$PourcentCreateVMFail=0;$PourcentCreateVMFailCSS=0;$HTMLVMFail=0
		$PourcentCreateVMCancel=0;$PourcentCreateVMCancelCSS=0;$HTMLVMCancel=0
		$Hour=(get-date).Hour
		$Minute=(get-date).Minute
		$NameTechnicianBodyHTML=[regex]::Match($Technician,'^[^@]*').Value
		$NameApplicantBodyHTML=[regex]::Match($Applicant,'^[^@]*').Value
		$NameResponsibleBodyHTML=[regex]::Match($Responsible,'^[^@]*').Value
		# Loop for each line in the CSV file and allows to create the virtual machines with command "New VM"
		foreach ($line in $PathCSVFormatNoTable){
			# Condition check if the line respect the limitations about size
			if (($line.NumCPU -le 2) -and ($line.MemoryMB -le 1572) -and ($line.DiskMB -le 125) -and ($line.DiskStorageFormat -eq "thick") -or ($line.DiskStorageFormat -eq "thin")){
				# Command to create virtual machine
				New-VM -VMHost $line.VMHost -Name $line.Name -Datastore $line.Datastore -ResourcePool $line.RessourcePool -NumCPU $line.NumCPU -MemoryMB $line.MemoryMB -DiskMB $line.DiskMB -DiskStorageFormat $line.DiskStorageFormat -CD -Floppy -Confirm:$false -ErrorVariable VMError 
				if ($? -eq $true){ 
					# Variable which contains the number of virtual machine created
					$CreateVMSucces++
					# Variable which contains the name of virtual machine created for the choice if the user want started the vms after creation
					$StartVMTrue +=, $line.Name 
					# Variable which contains the name of virtual machine created for the choice if the user want connect theiso imported after creation
					$IsoVMTrue +=, $line.Name 
					# [Math]::Floor make a integer division
					$PourcentCreateVMSucces=[Math]::Floor(($CreateVMSucces/$NBVM)*100)
					$PourcentCreateVMSuccesCSS=[Math]::Floor(($CreateVMSucces/$NBVM)*300)
					$HTMLVMSucces="($CreateVMSucces/$NBVM)"
					# Subject to Applicant (Success)
					$SubjectMailApplicant= "Succes for the creation of VM : $($line.name)"
					# Contains the body mail to Applicant (Success)
					$ContentMailApplicant=."$LocationScript\src\CreateVMCSV-ContentMailApplicant.ps1"
					Write-Host "SUCCES : The virtual machine" $line.Name "has been created with success" -ForegroundColor green
					# Command to send mail with reports success 
					Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicant -BodyAsHtml $ContentMailApplicant -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
					(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
				}
				elseif($? -eq $false){
					# Variable which contains the number of virtual machine badly created/not created
					$CreateVMFail++
					# [Math]::Floor make a integer division
					$PourcentCreateVMFail=[Math]::Floor(($CreateVMFail/$NBVM)*100)
					$PourcentCreateVMFailCSS=[Math]::Floor(($CreateVMFail/$NBVM)*300)
					$HTMLVMFail="($CreateVMFail/$NBVM)"
					# Subject to Technician (Error)
					$SubjectMailTechnician="Error during the attempt to create a VM : $($line.name)" 
					# Subject to Applicant (Fail)
					$SubjectMailApplicantErr= "Fail for the attempt to create a VM : $($line.name)"
					$CSSMailContent=Get-Content "$LocationScript\src\ContentMail-CSS.tcsrc3"
					# Contains the body mail to Technician (Error)
					$ContentMailTechnician=."$LocationScript\src\CreateVMCSV-ContentMailTechnician.ps1"
					$ContentMailTechnicianEnd=."$LocationScript\src\CreateVMCSV-ContentMailTechnician-End.ps1"
					# Contains the body mail to Applicant (Fail)
					$ContentMailApplicantErr=."$LocationScript\src\CreateVMCSV-ContentMailApplicantErr.ps1"
					# Command to send mail with reports error
					Write-Host "ERROR : The virtual machine $($line.name) has not been created or not created correctly because exists already or others issue" -ForegroundColor red
					# Send mail to technician
					Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Technician -Port $FromMailServerPort -Subject $SubjectMailTechnician -BodyAsHtml ($ContentMailTechnician+$JumpHTML+($VMError | ConvertTo-Html -Property Exception, CategoryInfo, ScriptStackTrace -head $CSSMailContent | out-string)+$ContentMailTechnicianEnd) -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
					(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
					# Send mail to applicant
					Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicantErr -BodyAsHtml $ContentMailApplicantErr -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
					(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
				}
			}
			# Cancel the creation of virtual machine if the line not respect the limitations about size
			elseif (($line.NumCPU -gt 2) -or ($line.MemoryMB -gt 1572) -or ($line.DiskMB -gt 125) -or ($line.DiskStorageFormat -ne "thick") -and ($line.DiskStorageFormat -ne "thin")){
				write-host "The virtual machine $($line.name) has been canceled not respect the limitations about size" -ForegroundColor Magenta
				# Variable which contains the number of virtual machine canceled
				$CreateVMCancel++
				# [Math]::Floor make a integer division
				$PourcentCreateVMCancel=[Math]::Floor(($CreateVMCancel/$NBVM)*100)
				$PourcentCreateVMCancelCSS=[Math]::Floor(($CreateVMCancel/$NBVM)*300)
				$HTMLVMCancel="($CreateVMCancel/$NBVM)"
				$SubjectMailApplicantCancel= "Request canceled to create a VM : $($line.name)"
				$ContentMailApplicantCancel=."$LocationScript\src\CreateVMCSV-ContentMailApplicantCancel.ps1"
				# Send mail to appliciant (select not create)
				Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicantCancel -BodyAsHtml $ContentMailApplicantCancel -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
				(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
			}
		}
		write-host "INFORMATION : $CreateVMSucces virtual machines have been created, $CreateVMFail not created/correctly with error and $CreateVMCancel canceled" -ForegroundColor gray
		# Subject to Reponsible
		$SubjectMailResponsible="Report all VMs creations"
		# Contains the body mail to Responsible
		$ContentMailResponsible=."$LocationScript\src\CreateVMCSV-ContentMailResponsible.ps1"
		# Command to send mail with reports responsible
		Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Responsible -Port $FromMailServerPort -Subject $SubjectMailResponsible -BodyAsHtml $ContentMailResponsible -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
		write-host "The reports were sent by email if they are not received it is because the specified addresses are incorrect" -ForegroundColor green
		# Command to delete the file which contains the password crypted and timeout between the last action and action "Connect iso file"
		Remove-Item $PathSecurityPassword
		Timeout /t 15
		# Ask if the user want connect the iso filed which has been imported before
		if ($Askimport -eq $ChoiceYes) {
			$AskconnectISO=read-host "Do you want connect the ISO imported with the virtual machines ? [Y] for Yes, [N] for No"
			# As long as the choice is not Y or N the question is reasked 
			while ($AskconnectISO -ne $ChoiceYes -and ($AskconnectISO -ne $ChoiceNo)){
    			$AskconnectISO=read-host "Do you want connect the ISO imported with the virtual machines ? [Y] for Yes, [N] for No"
			}
			if ($AskconnectISO -eq $ChoiceNo) {
    			write-host "MESSAGE : You have chosen not connect the iso file imported" -ForegroundColor Magenta
			}
			# If choice yes is selected link of virtual machines with iso  
			elseif ($AskconnectISO -eq $ChoiceYes) {
				write-host "MESSAGE : You have chosen connect the iso file imported" -ForegroundColor Cyan
				write-host "WARNING : Connection iso file on virtual machines in 10 seconds" -ForegroundColor Yellow
				timeout /t 10
				# Allows to delete everythings after the last "\" from the path specified when the iso file has been imported 
				# Initialize the variable 
				$IsoVMVMSucces=0;$IsoVMVMFail=0
    			$LastAntiSlash = $LocationISO.LastIndexOf("\")
    			$NameISO = $LocationISO.Substring($LastAntiSlash+1)
    			foreach ($line in $IsoVMTrue) {
					# Command to get the virtual machine then cd player and define the iso with option "Start connected turn on"
        			Get-VM -Name $line | Get-CDDrive | Set-CDDrive -StartConnected $true -IsoPath "[$LocationDatastore] $NameISO" -confirm:$false
        			if ($? -eq $true){
						# Variable which contains the number of virtual machine connected the iso with succes
            			$IsoVMVMSucces++
            			write-host "Succes : The virtual machine $line has been connected with iso file" -ForegroundColor green
        			}
        			elseif ($? -eq $false){
						# Variable which contains the number of virtual machine connected the iso with fail
            			$IsoVMVMFail++
            			write-host "ERROR : The virtual machine $line has not been connected with iso file" -ForegroundColor red
        			}
				}
				# Display the message with totality of machine connected or not connected with the iso file
				write-host "INFORMATION : $IsoVMVMSucces virtual machines are been connected with iso and $IsoVMVMFail not connected" -ForegroundColor gray
				Timeout /t 15
			}
		}
		# Ask if the user want start the virtual machine created if yes started else return to the homepage
		# Initialize the variable 
		$StartVMSucces=0; $StartVMFail=0
		$ChoiceStartVM=read-host "Do you want start all virtual machines created ? [Y] for Yes, [N] for No"
		while (($ChoiceStartVM -ne $ChoiceYes) -and ($ChoiceStartVM -ne $ChoiceNo)){
			$ChoiceStartVM=read-host "Do you want start all virtual machines created ? [Y] for Yes, [N] for No"
		}
		# If choice start vm after creation is "Y" the virtual machines are turn-on
		if ($ChoiceStartVM -eq $ChoiceYes){
			write-host "MESSAGE : You have chosen to start all virtual machines" -ForegroundColor cyan
			write-host "WARNING : If you have choosen start but no virtual machines has been created, return to the homepage" -ForegroundColor yellow
			foreach ($line in $StartVMTrue) {
				# Command to start virtual machine
				Start-VM -VM $line -Confirm:$false -ErrorAction Continue
				if ($? -eq $true){
					# Variable which contains the number of virtual machine strated
					$StartVMSucces++
					write-host "Succes : The virtual machine $line has been started" -ForegroundColor green
				}
				if ($? -eq $false){
					# Variable which contains the number of virtual machine not started
					$StartVMFail++
					write-host "ERROR : The virtual machine $line has not been started check on vSphere or others issue" -ForegroundColor red
				}
			}
			# Display the message with totality of machine started or not started with warning message
			write-host "WARNING : If you don't have seen message success or error it's because the virtual machine it's already started" -ForegroundColor Yellow
			write-host "INFORMATION : $StartVMSucces virtual machines have been started and $StartVMFail not started" -ForegroundColor gray
			write-host "Return to the homepage in 30 seconds" -ForegroundColor Gray
			Timeout /t 30
			return
		}
		# If choice start vm after creation is "N" return to the homepage
		elseif ($ChoiceStartVM -eq $ChoiceNo){
			write-host "MESSAGE : You have chosen to no start all virtual machines" -ForegroundColor Magenta
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return 
		}
	}
}

## Function CreateVM
# Allows to create a virtual machine with the parameters defined
Function CreateVM {
	write-host "You want create a virtual machine" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			# Remove the file which contains the password crypted
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
 	# Attempt to create virtual machine
		try{
		# Ask the user to specify the name, datastore ... of virtual machine he want create,
		# [int] is used to specify only a numbers not letters
   		$VMHOST=read-host "Specify on which ESXi you want create the virtual machine" 
    	$Name=read-host "Specify the name of virtual machine" 
    	$DataStore=read-host "Specify on which datastore you want create the virtual machine"
    	$RessourcePool=read-host "Specify on which ESXi resource the virtual machine will run" 
    	[int]$NumCPU=read-host "Specify the number of CPU (1 minimum)" -ErrorAction Stop
    	[int]$MemoryMB=read-host "Specify the number of RAM (4 minimum)" -ErrorAction Stop
    	[int]$DiskMB=read-host "Specify the size of disk by (Mo)" -ErrorAction Stop
		$DiskStorageFormat=read-host "Specify the format of procurement (thick or thin)"
		# Command to create virtual machine
		New-VM -VMHost $VMHost -Name $Name -Datastore $Datastore -ResourcePool $RessourcePool -NumCPU $NumCPU -MemoryMB $MemoryMB -DiskMB $DiskMB -DiskStorageFormat $DiskStorageFormat -CD -Floppy -Confirm:$false -ErrorAction Stop
		# If the virtual machine has been created display a message succes
    	if ($? -eq $true){
			write-host "SUCCES : The virtual $Name has been created" -ForegroundColor green
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
       	}
	}
	catch{
		# As long as the attempt of creation virtual machine failed the fields are reasked (reason read write-host below
    	while ($? -eq $false) {
			# Ask the user to specify the name, datastore ... of virtual machine he want create,
			# [int] is used to specify only a numbers not letters
        	write-host "ERROR : There are a error, fill all fields else check if the fields CPU,RAM and Disk are numbers or the virtual machine exist already or others issue" -ForegroundColor red
			$VMHOST=read-host "Specify on which ESXi you want create the virtual machine" 
			$Name=read-host "Specify the name of virtual machine" 
			$DataStore=read-host "Specify on which datastore you want create the virtual machine"
			$RessourcePool=read-host "Specify on which ESXi resource the virtual machine will run" 
			[int]$NumCPU=read-host "Specify the number of CPU (1 minimum)" 
			[int]$MemoryMB=read-host "Specify the number of RAM (4 minimum)" 
			[int]$DiskMB=read-host "Specify the size of disk by (Mo)" 
			$DiskStorageFormat=read-host "Specify the format of procurement (thick or thin)"
			# Command to delete virtual machine
			New-VM -VMHost $VMHost -Name $Name -Datastore $Datastore -ResourcePool $RessourcePool -NumCPU $NumCPU -MemoryMB $MemoryMB -DiskMB $DiskMB -DiskStorageFormat $DiskStorageFormat - CD -Floppy -Confirm:$false -ErrorAction Continue
			# If the virtual machine has been created display a message succes
        	if ($? -eq $true){	
				write-host "SUCCES : The virtual $Name has been created" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
        	}
    	}
	}
	# If the virtual machine has not been created display a message error and return to the homepage (reason read write-host below)
	if ($? -eq -$false){
    	write-host "ERROR : Despite your two attempts it did not work, field may be empty, wrong character entered, not exists, already exists or others issue try again later" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function DeleteVM
# Allows to delete specialy a virtual machine 

Function DeleteVM {
	write-host "You want delete a virtual machine" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validate, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			# Remove the file which contains the password crypted
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validate, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
 	# Attempt to delete virtual machine
	try{
		# Ask the user to specify the name of virtual machine he want delete
		$Name=read-host "Specify the name ov virtual machine you want delete" 
		# Command to delete virtual machine
		Remove-VM -VM $Name -DeleteFromDisk:$true -Confirm:$false -ErrorAction Stop
		# If the virtual machine has been deleted display a message succes
    	if ($? -eq $true){
			write-host "SUCCES : The virtual machine $Name has been deleteed" -ForegroundColor green
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
    	}
	}
	catch{
		# As long as the attempt of deletion virtual machine failed the fields are reasked (reason read write-host below)
    	while ($? -eq $false) {
        	write-host "ERROR : There are a error, fill all fields else check if the virtual machine is stopped, the name is correct or others issue" -ForegroundColor red
			$Name=read-host "Specify the name ov virtual machine you want delete" 
			# Command to delete virtual machine
			Remove-VM -VM $Name -DeleteFromDisk:$true -Confirm:$false -ErrorAction Continue
			# If the virtual machine has been deleted display a message succes
        	if ($? -eq $true){
				write-host "SUCCES : The virtual machine $Name has been deleted" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
        		}
    		}
		}
	# If the virtual machine has not been deleted display a message error and return to the homepage (reason read write-host below)
	if ($? -eq -$false){
		write-host "Despite your two attempts it did not work, field may be empty, virtual machine not stopped, wrong character entered, not exists or others issue try again later" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function DeleteVMCSV
# Allows to delete many virtual machines since a CSV File and purpose the choice
# to stop vm before deletion also send mail with reports
Function DeleteVMCSV {
	# Ask the user to specify the location of the CSV containing the parameters of the VM
	write-host "You want delete virtual machines since a CSV file" -ForegroundColor gray
	write-host 'WARNING : The delimiter in the CSV file must be ";" in order to be able to delete virtual machines' -ForegroundColor yellow
	$LocationCSV=read-host 'Specify the location of CSV file "Exemple : (C:/windows/Kyosuko.csv)"'
	# Check if the CSV file exists with the extension .csv
	$CheckLocationCSV=Get-Item $LocationCSV ; $CheckLocationCSV.Extension
	# If the file exists, a message, success and warning is displayed
	if ($CheckLocationCSV.Extension -eq ".csv") {
    	write-host "SUCCES : The file specifed exist with the good extension .csv" -ForegroundColor green
    	write-host 'WARNING : If you don''t use the delimiter ";" in the CSV file you must change else not working correctly'  -ForegroundColor yellow
	}
	# As long as the file specified in the $LocationCSV variable is not a csv file, a new entry is displayed with an error message
	While ($CheckLocationCSV.Extension -ne ".csv") {
		write-host 'ERROR : The file than you have specify is not valide check if it''s the good path or if there are the extension ".csv"' -ForegroundColor red
		$LocationCSV=read-host 'Specify the location of CSV file "Exemple : (C:/windows/Kyosuko.csv)"'
		$CheckLocationCSV=Get-Item $LocationCSV ; $CheckLocationCSV.Extension
		# If the file exists, a message, success and warning is displayed
		if ($CheckLocationCSV.Extension -eq ".csv") {
    		write-host "SUCCES : The file specifed exist with the good extension .csv" -ForegroundColor green
    		write-host 'WARNING : If you don''t use the delimiter ";" in the CSV file you must change else not working correctly'  -ForegroundColor yellow
		}
	}
	# Check than for the first line there are a delimiter ";"
	# A timeout between the last action the new 
	timeout /t 5
	$CheckDelimiter=Get-content $LocationCSV | Select -First 1
	if ($CheckDelimiter -like "*;*"){
		write-host 'SUCCES : The delimiter used is ";"' -ForegroundColor Green
	}
	else {
		write-host 'ERROR : You don''use the delimiter ";" please use it and retry' -ForegroundColor red
		write-host "Return to the homepage in 30 seconds" -ForegroundColor Gray
	}
	# A timeout between the last action the new then importation the CSV file and display message success, information and warning
	# Also a message with version PowerShell is displayed
	timeout /t 5
	Import-CSV -Path $LocationCSV -Delimiter $Delimiter | Format-table
	write-host "SUCCES : Import successful" -ForegroundColor green
	write-host "WARNING : If you not see correctly the table with the values it's because the file is empty or you don't use the good delimiter so solve this problem else problem during delete VMs" -ForegroundColor yellow
	timeout /t 5
	JumpLine
	write-host 'WARNING : To use Power CLI you must have a version PowerShell "5" at least if this is not the case `
upgrade to continue, otherwise the utility will not work properly' -ForegroundColor yellow
	write-host "INFORMATION : Your PowerShell version is as follows :" $PSVersionTable.PSVersion.Major -ForegroundColor gray
	# A check of version PowerShell is "5" or upper and if it's okay display message success else a error message and propose 
	# if he want upgrade PowerShell a message display how to upgrade else return to the homepage
	if ((($Host.Version.Major) -eq 5) -or (($Host.Version.Major)-gt [int]5)) {
		Write-host 'SUCCES : You have version "5" it''s okay' -ForegroundColor green
	}
	else {
    	write-host 'ERROR : You don''t have version "5", please upgrade your PS' -ForegroundColor red
		$ChoicePS=read-host "Do you want upgrade you Power-Shell to the last Version ? [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
		if ($ChoicePS -eq $ChoiceYes){
			write-host "MESSAGE : You have chosen to upgrade PowerShell" -ForegroundColor cyan
			write-host "INFORMATION : To Upgrade you power-shell you must download minimum .NetFramwork 4.5 and WMF 5.0 (With KB)" -ForegroundColor gray
			write-host "INFORMATION : Or download minimum .NetFramwork 4.5 and install with msi" -ForegroundColor gray
			write-host "Return to the homepage in 30 seconds" -ForegroundColor Gray
			Timeout /t 30
			return
		}
		elseif ($ChoicePS -eq $ChoiceNo){
    		write-host "MESSAGE : You have chosen to not installed the PowerShell, try resolve the issue" -ForegroundColor Magenta
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
		# As long as the choice is not Y or N the question is reasked if he want upgrade PowerShell and after choice
		# if he want upgrade PowerShell a message display how to upgrade else return to the homepage
		while (($ChoicePS -ne $ChoiceYes) -and ($ChoicePS -ne $ChoiceNo)){
   			$ChoicePS=read-host "Do you want upgrade PowerShell? [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
			if ($ChoicePS -eq $ChoiceYes){
				write-host "MESSAGE : You have chosen to upgrade PowerShell" -ForegroundColor cyan
				write-host "INFORMATION : To Upgrade you power-shell you must download minimum .NetFramwork 4.5 and WMF 5.0 (With KB)" -ForegroundColor gray
				write-host "INFORMATION : Or download minimum .NetFramwork 4.5 and install with msi" -ForegroundColor gray
				write-host "Return to the homepage in 30 seconds" -ForegroundColor Gray
				Timeout /t 30
				return
			}
			elseif ($ChoicePS -eq $ChoiceNo){
				write-host "MESSAGE : You have chosento not installed the PowerShell, try resolve the issue" -ForegroundColor Magenta
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
			}
		}
	}
	# A timeout between the last action the next action "PowerCLI"
	timeout /t 5
	JumpLine
	# A check if PowerCLI is installed it's good display a message success else asked if choice yes it install else return
	# to homepage
	write-host "WARNING : To use Power CLI you must have the module installed" -ForegroundColor yellow
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : Power CLI is not installed" -ForegroundColor red
		$ChoicePC=read-host "Do you want upgrade PowerShell? [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
	}
	else{
		$ChoicePC="Installed"
		write-host "SUCCES : PowerCLI is already installed" -ForegroundColor green
	}
	if ($ChoicePC -eq $ChoiceYes){
		try {
			# Commands to put Tls version and install module vmware and Nuget which allows find and download the module
			# PowerCLI since the "PSGallery"
			write-host "MESSAGE : You have chosen to install PowerCLI" -ForegroundColor cyan
			write-host 'Not cut during the installation, please wait' -ForegroundColor yellow
			[Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls" 
			Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -confirm:$false -ErrorAction Stop
			Set-PSRepository -Name "PSGallery" -InstallationPolicy Trusted -ErrorAction Stop
			Install-Module -Name VMware.PowerCLI -Scope CurrentUser -confirm:$false -ErrorAction Stop
		}
		catch {
			write-host "ERROR : PowerCLI has not been installed, try resolve this issue" -ForegroundColor red
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
		finally {
			# Import module PowerCLI 
			# Allows to ignorate certificate no valide but disable if you a certificate
			Import-Module VMware.PowerCLI
			Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
			write-host "SUCCES : PowerCLI has been installed" -ForegroundColor green
		}
	}
	elseif ($ChoicePC -eq $ChoiceNo){
		write-host "MESSAGE : You have chosen to not install Power CLI, try resolve the issue" -ForegroundColor Magenta
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# As long as the choice is not Y,N or already installed the question is reasked if he want install PowerCLI and after choice
	# if it's yes it install else return to the homepage
	while (($ChoicePC -ne $ChoiceYes) -and ($ChoicePC -ne $ChoiceNo) -and ($ChoicePC -ne "Installed")){
		$ChoicePC=read-host "Do you want installed PowerCLI ? [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
		if ($ChoicePC -eq $ChoiceYes){
			try {
				# Commands to put Tls version and install module vmware and Nuget which allows find and download the module
				# PowerCLI since the "PSGallery"
				write-host "MESSAGE : You have chosen to install PowerCLI" -ForegroundColor cyan
				write-host 'Not cut during the installation, please wait' -ForegroundColor yellow
				[Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls" 
				Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -confirm:$false -ErrorAction Stop
				Set-PSRepository -Name "PSGallery" -InstallationPolicy Trusted -ErrorAction Stop
				Install-Module -Name VMware.PowerCLI -Scope CurrentUser -confirm:$false -ErrorAction Stop
			}
			catch {
				write-host "ERROR : PowerCLI has not been installed, try resolve this issue" -ForegroundColor red
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
			}
			finally {
				# Import module PowerCLI 
				# Allows to ignorate certificate no valide but disable if you a certificate
				write-host "INFORMATION : Please wait importation of module PowerCLI" -ForegroundColor gray
				Import-Module VMware.PowerCLI
				Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
				write-host "SUCCES : PowerCLI has been installed" -ForegroundColor green
			}
		}
		elseif ($ChoicePC -eq $ChoiceNo){
			write-host "MESSAGE : You have chosen to not install Power CLI, try resolve the issue" -ForegroundColor Magenta
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
	}
	# A timeout between the last action the next action "connect vSphere" and display message warning
	timeout /t 5
	JumpLine
	write-host "INFORMATION : Now you are able to connect to vSphere for deletion of VMs" -ForegroundColor gray
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validate, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			# Remove the file which contains the password crypted
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validate, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
	# Allows to count the number of line without the first and spaces and got the number of virtual machines than
	# the user want delete
	$CheckNBVM=Get-content $LocationCSV | Where-Object { $_ } | Measure-Object
	$NBVM=$CheckNBVM.count-1
	# Display the number of virtual machines asked to delete with timeout between this action and ask continue
	write-host "INFORMATION : There are " $NBVM "virtual machines that will be delete" -ForegroundColor gray
	timeout /t 10
	# Ask if the user want continue after the last informations gived
	$Askcontinue=read-host "Do you want continue ? [Y] for Yes, [N] for No"
	# As long as the choice is not Y or N the question is reasked and after choice if it's yes it continue else return to the homepage
	while ($Askcontinue -ne $ChoiceYes -and ($AskContinue -ne $ChoiceNo)){
		$Askcontinue=read-host "Do you want continue ? [Y] for Yes, [N] for No"
	}
	if ($AskContinue -eq $ChoiceNo) {
		write-host "MESSAGE : You have chosen to not continue" -ForegroundColor Magenta
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	elseif ($AskContinue -eq $ChoiceYes) {
		write-host "MESSAGE : You have chosen to continue" -ForegroundColor Cyan
	}
	# Ask to the user if he want send the reports by mail after deletion of virtual machine
	$Askreports=read-host "Do you want send the reports by mail after delation of virtual machines ?`
[Y] for Yes, [N] for No"
	# As long as the choice is not Y or N the question is reasked 
	while ($Askreports -ne $ChoiceYes -and ($Askreports -ne $ChoiceNo)){
		$Askreports=read-host "Do you want send the reports by mail after delation of virtual machines ? `
[Y] for Yes, [N] for No"
	}
	if ($Askreports -eq $ChoiceNo) {
		write-host "MESSAGE : You have chosen not send the reports by mail" -ForegroundColor Magenta
	}
	elseif ($Askreports -eq $ChoiceYes) {
		write-host "MESSAGE : You have chosen send the reports by mail" -ForegroundColor Cyan
	}
	# Import the CSV file without format table 
	$PathCSVFormatNoTable=Import-CSV $LocationCSV -Delimiter $Delimiter 
	# If the choice to send reports has not been selected the deletion of the virtual machines will be make without reports
	if ($Askreports -eq $ChoiceNo){
		# Initialize the variable 
		$StopVMFailSucces=0; $StopVMFail=0
		Write-Host "WARRNING : It's recommanded that the virtual machines are stopped before deletion" -ForegroundColor yellow
		# Ask if the user want stop all virtual machines before the delation
		$ChoiceStopVM=read-host "Do you want stop all virtual machines before deletion  ? [Y] for Yes, [N] for No"
		# As long as the choice is not Y or N the question is reasked 
		while (($ChoiceStopVM -ne $ChoiceYes) -and ($ChoiceStopVM -ne $ChoiceNo)){
			Write-Host "WARRNING : It's recommanded that the virtual machines are stopped before deletion" -ForegroundColor yellow
			$ChoiceStopVM=read-host "Do you want stop all virtual machines before deletion ? [Y] for Yes, [N] for No"
		}
		# If choice yes is selected deletion of virtual machines with a loop
		if ($ChoiceStopVM -eq $ChoiceYes){
			write-host "MESSAGE : You have chosen to stop all virtual machines" -ForegroundColor cyan
			foreach ($line in $PathCSVFormatNoTable){
				Stop-VM -VM $line.Name -Confirm:$false -ErrorAction Continue
				if ($? -eq $true){
					# Variable which contains the number of virtual machine stopped
					$StopVMFailSucces++
					write-host "Succes : The virtual machine $line has been stopped" -ForegroundColor green
				}
				if ($? -eq $false){
					# Variable which contains the number of virtual machine not stopped
					$StopVMFail++
					write-host "ERROR : The virtual machine $line has not been stopped, not exists or already stopped" -ForegroundColor red
				}
			}
			# Display the message with totality of machine stopped or not stopped
			write-host "WARNING : If you don't have seen message success or error it's because the virtual machine it's already stopped" -ForegroundColor Yellow
			write-host "INFORMATION : $StopVMFailSucces virtual machines have been stopped and $StopVMFail not stopped" -ForegroundColor gray
			Timeout /t 10
		}
		if ($ChoiceStopVM -eq $ChoiceNo){
			write-host "MESSAGE : You have chosen to no stop all virtual machines" -ForegroundColor Magenta
			Timeout /t 10
		}
		# Ask the user if he want continue
		$Askcontinue=read-host "Do you want continue ? [Y] for Yes, [N] for No"
		# As long as the choice is not Y or N the question is reasked
		while ($Askcontinue -ne $ChoiceYes -and ($AskContinue -ne $ChoiceNo)){
			$Askcontinue=read-host "Do you want continue ? [Y] for Yes, [N] for No"
		}
		# If the choice is no return to the homepage
		if ($AskContinue -eq $ChoiceNo) {
			write-host "MESSAGE : You have chosen to not continue" -ForegroundColor Magenta
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
		elseif ($AskContinue -eq $ChoiceYes) {
			write-host "MESSAGE : You have chosen to continue" -ForegroundColor Cyan
		}
		# Deletion of virtual machines
		# Initialize the variable 
		write-host "WARNING : Deletion of virtual machines in 10 seconds" -ForegroundColor Yellow
		timeout /t 10
		$DeleteVMSucces=0;$DeleteVMFail=0;$DeleteVMCancel=0
		foreach ($line in $PathCSVFormatNoTable){
			# Commands to check if the virtual machine is turn-off
			$Get=Get-VM -name $line.name
			$CheckTurnoff=$Get.PowerState
			if ($CheckTurnoff -eq "PoweredOff") {
				# Command to delete virtual machine
				Remove-VM -VM $line.Name-DeleteFromDisk:$true -Confirm:$false
				if ($? -eq $true){
					# Variable which contains the number of virtual machine deleted
					$DeleteVMSucces++
					Write-Host "SUCCES : The virtual machine" $line.Name "has been delete with success" -ForegroundColor green
				}
				elseif($? -eq $false){
					# Variable which contains the number of virtual machine deleted
					$DeleteVMFail++
					Write-Host "ERROR : The virtual machine" $line.Name "has not been deleted not exists, suspend or already stopped" -ForegroundColor red
				}
			}
			else{
				# Variable which contains the number of virtual machine canceled
				$DeleteVMCancel++
				write-host "The virtual machine $($line.name) has not been deleted so canceled because always turn-on" -ForegroundColor Magenta
			}
		}
		# Display the message with totality of machine deleted or not deleted with information message
		write-host "INFORMATION : $DeleteVMSucces virtual machines have been  deleted and $DeleteVMFail not deleted with error and $DeleteVMCancel canceled" -ForegroundColor gray
		write-host "Return to the homepage in 30 seconds" -ForegroundColor Gray
		Timeout /t 30
		return
	}
	# If the choice to send reports has been selected the deletion of the virtual machines will be make with reports
	if ($Askreports -eq $ChoiceYes){
		# Check if Telnet is installed to tester to connection between server mail
		write-host "WARNING : To send emails telnet is required to do a connection test" -ForegroundColor yellow
		# Commands to check if telnet is installed and get the version of Windows (Server, Workstation)
		$CheckTelnet=get-command -name *telnet*
		if ([string]::IsNullOrEmpty($CheckTelnet)){
			write-host "ERROR : Telnet is not installed" -ForegroundColor red
			$ChoiceTelnet=read-host "Do you want install Telnet [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
		}
		else{
			$ChoiceTelnet="Installed"
			write-host "SUCCES : Telnet is already installed" -ForegroundColor green
		}
		# If the version Windows contains the word "Server" (Windows Server) and choice installation telnet is "Y" so installation of functionality Telnet
		# by Dism
		if (($ChoiceTelnet -eq $ChoiceYes) -and ($GetCheckVersionWindows -notlike "*Server*")){
			try {
				write-host "MESSAGE : You have chosen to install Telnet" -ForegroundColor cyan
				dism /Online /Enable-Feature /featurename:TelnetClient -ErrorAction Stop
			}
			catch {
				write-host "ERROR : Telnet has not been installed, try resolve this issue" -ForegroundColor red
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
			}
			finally {
				write-host "SUCCES : Telnet has been installed" -ForegroundColor green
			}
		}
		# If the version Windows contains not the word "Server" (Windows Workstation) and choice installation telnet is "Y" so installation of functionality Telnet
		# by WindowsFeature
		elseif (($ChoiceTelnet -eq $ChoiceYes) -and ($GetCheckVersionWindows -like "*Server*")){
			try {
				write-host "MESSAGE : You have chosen to install Telnet" -ForegroundColor cyan
				Install-WindowsFeature Telnet-Client -ErrorAction Stop
			}
			catch {
				write-host "ERROR : Telnet has not been installed, try resolve this issue" -ForegroundColor red
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
			}
			finally {
				write-host "SUCCES : Telnet has been installed" -ForegroundColor green
			}
		}
		elseif ($ChoiceTelnet -eq $ChoiceNo){
			write-host "MESSAGE : You have chosen to not install Telnet, try resolve this issue to create virtual machines with send mails" -ForegroundColor Magenta
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
		# As long as the choice is not Y, N ro already installed the question is reasked 
		while (($ChoiceTelnet -ne $ChoiceYes) -and ($ChoiceTelnet -ne $ChoiceNo) -and ($ChoiceTelnet -ne "Installed")){
			$ChoiceTelnet=read-host "Do you want installed Telnet ? [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
			if (($ChoiceTelnet -eq $ChoiceYes) -and ($GetCheckVersionWindows -notlike "*Server*")){
				try {
					write-host "MESSAGE : You have chosen to installed Telnet" -ForegroundColor cyan
					Install-WindowsFeature Telnet-Client -ErrorAction Stop
				}
				catch {
					write-host "ERROR : Telnet has not been installed, try resolve this issue" -ForegroundColor red
					write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
					Timeout /t 10
					return
				}
				finally {
					write-host "SUCCES : Telnet has been installed" -ForegroundColor green
				}
			}
			elseif (($ChoiceTelnet -eq $ChoiceYes) -and ($GetCheckVersionWindows -like "*Server*")){
				try {
					write-host "MESSAGE : You have chosen to installed Telnet" -ForegroundColor cyan
					dism /Online /Enable-Feature /featurename:TelnetClient -ErrorAction Stop
				}
				catch {
					write-host "ERROR : Telnet has not been installed, try resolve this issue" -ForegroundColor red
					write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
					Timeout /t 10
					return
				}
				finally {
					write-host "SUCCES : Telnet has been installed" -ForegroundColor green
				}
			}
			# If the choice installation TelNet is "N" return to home page
			elseif ($ChoiceTelnet -eq $ChoiceNo){
				write-host "MESSAGE : You have chosen to not install Telnet it's necessary, try resolve the issue" -ForegroundColor Magenta
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
			}
		}
		# Ask the user to specify the credentials of mail server to test send mail and they will be used for send the reports if work
		write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
		$FromMailServer = read-host "Specify the mail server address of sender" 
		$FromMailServerPort = read-host "Specify the port of mail server"
		# As long as than the fields is empty the fills are reasked
		while (([string]::IsNullOrEmpty($FromMailServerPort)) -or ([string]::IsNullOrEmpty($FromMailServer))) {
			write-host "ERROR : All fields must be filled" -ForegroundColor red
			write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
			$FromMailServer=read-host "Specify the mail server address of sender" 
			[int]$FromMailServerPort=read-host "Specify the port of mail server"
		}
		try{
		# Command to test the connection of server mail via Telnet
		$Testconnection=Test-NetConnection $FromMailServer -port $FromMailServerPort 
		while ($Testconnection.tcptestsucceeded -eq $false){
			write-host "ERROR : The connection has not been etablished bad informations used, server state or others issue retry" -ForegroundColor red
			write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
			$FromMailServer=read-host "Specify the mail server address of sender" 
			[int]$FromMailServerPort=read-host "Specify the port of mail server"
			while (([string]::IsNullOrEmpty($FromMailServerPort)) -or ([string]::IsNullOrEmpty($FromMailServer))) {
				write-host "ERROR : All fields must be filled" -ForegroundColor red
				write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
				$FromMailServer=read-host "Specify the mail server address of sender" 
				[int]$FromMailServerPort=read-host "Specify the port of mail server"
				}
			# Command to test the connection of server mail via Telnet
			$Testconnection=Test-NetConnection $FromMailServer -port $FromMailServerPort     
			}
		}
		catch{
			# If the test connection fail the fills are reasked
			write-host "ERROR : The connection has not been etablished bad informations used, server state or others issue retry" -ForegroundColor red
			write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
			$FromMailServer=read-host "Specify the mail server address of sender" 
			[int]$FromMailServerPort=read-host "Specify the port of mail server"  
			# As long as than the fields is empty the fills are reasked
			while (([string]::IsNullOrEmpty($FromMailServerPort)) -or ([string]::IsNullOrEmpty($FromMailServer))) {
				write-host "ERROR : All fields must be filled else connection " -ForegroundColor red
				write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
				$FromMailServer=read-host "Specify the mail server address of sender" 
				[int]$FromMailServerPort=read-host "Specify the port of mail server"
			}
			$Testconnection=Test-NetConnection $FromMailServer -port $FromMailServerPort 
		}
		# If the command to test the connection of server mail has worked display a message success
		if ($Testconnection.tcptestsucceeded -eq $true){
			Write-Host "SUCCES : The connection has been established" -ForegroundColor green
		}
		# If the command to test the connection of server mail is always fail display a message error and return to the homepage
		elseif ($? -eq $false){
			write-host "ERROR : Despite your two attempts, this did not work empty field, bad informations used, server state or others issue retry later" -ForegroundColor red
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
		# Email address that will be used to receive the test sending email
		write-host "WARNING : To send report by mail a test send mail will be make" -ForegroundColor yellow
		write-host "WARNING : If you use a server mail public please use the port 587 else not work check read-me for more details" -ForegroundColor yellow
		$MailEncodage="UTF8"  
		$MailTest="Kyosukoxxx@gmail.com"
		$SubjectMailTest="Do not Reply : Send mail test about creation of VM"
		$ContentMailTest="Hey, if you receive this mail it's because the send mail work with the credentials"
		try{
			# Specify the e-mail address and password that will be used to send the report
			$FromMailUserMail=read-host "Specify the mail address of sender" 
			read-host "Specify the password of mail address to sender" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -ErrorAction stop -confirm:$false 
			# As long as than the fields is empty the fills are reasked 
			while ([string]::IsNullOrEmpty($FromMailUserMail)) {
				write-host "ERROR : All fields must be filled" -ForegroundColor red
				$FromMailUserMail=read-host "Specify the mail address of sender" 
				read-host "Specify the password of mail address to sender" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -ErrorAction stop -confirm:$false 
			}
			# Allows to specify the mail the "from" in the mail
			$Mailaddressfrom=$FromMailUserMail
			# Command to send mail test
			Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $MailTest -Port $FromMailServerPort -Subject $SubjectMailTest -Body $ContentMailTest -BodyAsHtml -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction Stop
		}
		catch{
			# If the command send mail test has not worked the user must specify the e-mail address and password that will be used to send the report 
			write-host "ERROR : All fields must be filled or the send mail has not worked, try yet" -ForegroundColor red
			$FromMailUserMail=read-host "Specify the mail address of sender" 
			read-host "Specify the password of mail address to sender" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -ErrorAction stop -confirm:$false 
			# As long as than the fields is empty the fills are reasked 
			while ([string]::IsNullOrEmpty($FromMailUserMail)) {
				write-host "ERROR : All fields must be filled" -ForegroundColor red
				$FromMailUserMail=read-host "Specify the mail address of sender" 
				read-host "Specify the password of mail address to sender" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -ErrorAction stop -confirm:$false 
			}
			# Allows to specify the mail the "from" in the mail
			$Mailaddressfrom=$FromMailUserMail
			# Command to send mail test
			Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $MailTest -Port $FromMailServerPort -Subject $SubjectMailTest -Body $ContentMailTest -BodyAsHtml -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
		}
		# If the send mail test has worked display a message succes
		if ($? -eq $true){
			Write-Host "SUCCES : The send mail test has worked " -ForegroundColor green
		}
		# If the send mail test has not worked display a message error and delete the file which contains the password crypted
		elseif ($? -eq $false){
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Despite your two attempts, this did not work empty field, bad informations used, server state or others issue retry later" -ForegroundColor red
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
		# Ask the user to put the addresses mail of recipients
		write-host "WARNING : The addresses mail entered will be used like recipients" -ForegroundColor yellow
		$Technician=read-host "Specify the mail address of technician"
		$Applicant=read-host "Specify the mail address of applicant"
		$Responsible=read-host "Specify the mail address of responsible"
		# As long as than the fields is empty the fills are reasked 
		while (([string]::IsNullOrEmpty($Technician)) -or ([string]::IsNullOrEmpty($Applicant)) -or ([string]::IsNullOrEmpty($Responsible))){
			write-host "ERROR : An error occurred, please complete all fields" -ForegroundColor red
			$Technician=read-host "Specify the mail address of technician"
			$Applicant=read-host "Specify the mail address of applicant"
			$Responsible=read-host "Specify the mail address of responsible"
		}
		# Initialize the variable with timeout before the last action and the new
		Timeout /t 10
		$StopVMFailSucces=$null; $StopVMFail=$null
		Write-Host "WARRNING : It's recommanded that the virtual machines are stopped before deletion" -ForegroundColor yellow
		# Ask if the user want stop all virtual machines before the delation
		$ChoiceStopVM=read-host "Do you want stop all virtual machines before deletion  ? [Y] for Yes, [N] for No"
		# As long as the choice is not Y or N the question is reasked 
		while (($ChoiceStopVM -ne $ChoiceYes) -and ($ChoiceStopVM -ne $ChoiceNo)){
			Write-Host "WARRNING : It's recommanded that the virtual machines are stopped before deletion" -ForegroundColor yellow
    		$ChoiceStopVM=read-host "Do you want stop all virtual machines before deletion ? [Y] for Yes, [N] for No"
		}
		# If choice yes is selected deletion of virtual machines with a loop
		if ($ChoiceStopVM -eq $ChoiceYes){
    		write-host "MESSAGE : You have chosen to stop all virtual machines" -ForegroundColor cyan
    		foreach ($line in $PathCSVFormatNoTable){
        		Stop-VM -VM $line.Name -Confirm:$false -ErrorAction Continue
        		if ($? -eq $true){
					# Variable which contains the number of virtual machine stopped
					$StopVMFailSucces++
            		write-host "Succes : The virtual machine $line has been stopped" -ForegroundColor green
        		}
        		if ($? -eq $false){
					# Variable which contains the number of virtual machine not stopped
					$StopVMFail++
            		write-host "ERROR : The virtual machine $line has not been stopped, not exists, suspend or already stopped" -ForegroundColor red
        		}
			}
			# Display the message with totality of machine stopped or not stopped
			write-host "WARNING : If you don't have seen message success or error it's because the virtual machine it's already stopped" -ForegroundColor Yellow
			write-host "INFORMATION : $StopVMFailSucces virtual machines have been stopped and $StopVMFail not stopped" -ForegroundColor gray
			timeout /t 10
		}
		if ($ChoiceStopVM -eq $ChoiceNo){
			write-host "MESSAGE : You have chosen to no stop all virtual machines" -ForegroundColor Magenta
			timeout /t 10
		}
		# Ask the user if he want continue
		$Askcontinue=read-host "Do you want continue ? [Y] for Yes, [N] for No"
		# As long as the choice is not Y or N the question is reasked
		while ($Askcontinue -ne $ChoiceYes -and ($AskContinue -ne $ChoiceNo)){
			$Askcontinue=read-host "Do you want continue ? [Y] for Yes, [N] for No"
		}
		# If the choice is no return to the homepage
		if ($AskContinue -eq $ChoiceNo) {
			write-host "MESSAGE : You have chosen to not continue" -ForegroundColor Magenta
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
		elseif ($AskContinue -eq $ChoiceYes) {
			write-host "MESSAGE : You have chosen to continue" -ForegroundColor Cyan
		}
		# Display a message deletion of virtual machine with timeout
		write-host "WARNING : Deletion of virtual machines in 10 seconds" -ForegroundColor Yellow
		timeout /t 10
		# Declaration of variables container the numbers of deletion vm success, fail and a pourcentage also a pourcentage for the gauge in the mail (CSS).
		# Commands to recup only the beginning of address mail before "@"
		# Initialize the variable 
		$DeleteVMSucces=0;$DeleteVMFail=0;$DeleteVMCancel=0
		$PourcentDeleteVMSucces=0;$PourcentDeleteVMSuccesCSS=0;$HTMLVMSucces=0
		$PourcentDeleteVMFail=0;$PourcentDeleteVMFailCSS=0;$HTMLVMFail=0
		$Hour=(get-date).Hour
		$Minute=(get-date).Minute
		$NameTechnicianBodyHTML=[regex]::Match($Technician,'^[^@]*').Value
		$NameApplicantBodyHTML=[regex]::Match($Applicant,'^[^@]*').Value
		$NameResponsibleBodyHTML=[regex]::Match($Responsible,'^[^@]*').Value
		# Loop for each line in the CSV file and allows to delete the virtual machines with command "New VM"
		foreach ($line in $PathCSVFormatNoTable){
			# Commands to check if the virtual machine is turn-off
			$Get=Get-VM -name $line.name
			$CheckTurnoff=$Get.PowerState
			if ($CheckTurnoff -eq "PoweredOff") {
				# Command to delete virtual machine
				Remove-VM -VM $line.Name -DeleteFromDisk:$true -Confirm:$false -ErrorVariable VMError
				if ($? -eq $true){
					# Variable which contains the number of virtual machine deleted
					$DeleteVMSucces++
					# [Math]::Floor make a integer division
					$PourcentDeleteVMSucces=[Math]::Floor(($DeleteVMSucces/$NBVM)*100)
					$PourcentDeleteVMSuccesCSS=[Math]::Floor(($DeleteVMSucces/$NBVM)*300)
					$HTMLVMSucces="($DeleteVMSucces/$NBVM)"
					# Subject to Applicant (Success)
					$SubjectMailApplicant= "Succes for the deletion of VM : $($line.name)"
					# Contains the body mail to Applicant (Success)
					$ContentMailApplicant=."$LocationScript\src\DeleteVMCSV-ContentMailApplicant.ps1"
					Write-Host "SUCCES : The virtual machine $($line.name) has been deleted with success" -ForegroundColor green
					# Command to send mail with reports success 
					Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicant -BodyAsHtml $ContentMailApplicant -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
					(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
				}
				elseif($? -eq $false){
					# Variable which contains the number of virtual machine deleted
					$DeleteVMFail++
					# [Math]::Floor make a integer division
					$PourcentDeleteVMFail=[Math]::Floor(($DeleteVMFail/$NBVM)*100)
					$PourcentDeleteVMFailCSS=[Math]::Floor(($DeleteVMFail/$NBVM)*300)
					$HTMLVMFail="($DeleteVMFail/$NBVM)"
					# Subject to Techinician (Error)
					$SubjectMailTechnician="Error during the attempt to delete a VM : $($line.name)" 
					# Subject to Applicant (Fail)
					$SubjectMailApplicantErr= "Fail for the deletion of VM : $($line.name)"
					$CSSMailContent=Get-Content "$LocationScript\src\ContentMail-CSS.tcsrc3"
					# Contains the body mail to Technician (Error)
					$ContentMailTechnician=."$LocationScript\src\DeleteVMCSV-ContentMailTechnician.ps1"
					$ContentMailTechnicianEnd=."$LocationScript\src\DeleteVMCSV-ContentMailTechnician-End.ps1"
					# Contains the body mail to Applicant (Fail)
					$ContentMailApplicantErr=."$LocationScript\src\DeleteVMCSV-ContentMailApplicantErr.ps1"
					write-host "ERROR : The virtual machine $($line.name) has not been deleted not exists, not stopped or others issue" -ForegroundColor red
					# Command to send mail with reports error
					# Send mail to Technician
					Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Technician -Port $FromMailServerPort -Subject $SubjectMailTechnician -BodyAsHtml ($ContentMailTechnician+$JumpHTML+($VMError | ConvertTo-Html -Property Exception, CategoryInfo, ScriptStackTrace -head $CSSMailContent | out-string)+$ContentMailTechnicianEnd) -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
					(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
					# Send mail to Applicant
					Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicantErr -BodyAsHtml $ContentMailApplicantErr -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
					(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
				}
			}
			else{
				write-host "The virtual machine $($line.name) has not been deleted so canceled because always turn-on" -ForegroundColor Magenta
				# Variable which contains the number of virtual machine canceled
				$DeleteVMCancel++
				# [Math]::Floor make a integer division
				$PourcentDeleteVMCancel=[Math]::Floor(($DeleteVMCancel/$NBVM)*100)
				$PourcentDeleteVMCancelCSS=[Math]::Floor(($DeleteVMCancel/$NBVM)*300)
				$HTMLVMCancel="($DeleteVMCancel/$NBVM)"
				# Subject to Applicant (Cancel)
				$SubjectMailApplicantCancel= "Request canceled to delete a VM : $($line.name)"
				# Contains the body mail to Applicant (Cancel)
				$ContentMailApplicantCancel=."$LocationScript\src\DeleteVMCSV-ContentMailApplicantCancel.ps1"
				# Send mail to applicant (select not delete)
				Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Applicant -Port $FromMailServerPort -Subject $SubjectMailApplicantCancel -BodyAsHtml $ContentMailApplicantCancel -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
				(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
			}
        }
		# Display the message with totality of machine deleted or not deleted with information message
		write-host "INFORMATION : $DeleteVMSucces virtual machines have been deleted and $DeleteVMFail not deleted with error and $DeleteVMCancel canceled" -ForegroundColor gray
		# Subject to Reponsible
		$SubjectMailResponsible="Report all VMs deletions"
		# Contains the body mail to Responsible
		$ContentMailResponsible=."$LocationScript\src\DeleteVMCSV-ContentMailResponsible.ps1"
		# Command to send mail with reports responsible
		Send-MailMessage -SmtpServer $FromMailServer -From $Mailaddressfrom -To $Responsible -Port $FromMailServerPort -Subject $SubjectMailResponsible -BodyAsHtml $ContentMailResponsible -Encoding $MailEncodage -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$FromMailUserMail",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -UseSsl -ErrorAction continue
		write-host "The reports were sent by email if they are not received it is because the specified addresses are incorrect" -ForegroundColor gray
		Remove-Item $PathSecurityPassword
		Timeout /t 5
		write-host "Return to the homepage in 30 seconds" -ForegroundColor Gray
		Timeout /t 30
		return 
	}
}

## Function DeleteVMInventory
# Allows to delete specialy a virtual machine from inventory vSphere (not datastore)

Function DeleteVMInventory {
	write-host "You want delete a virtual machine from vSphere (not datastore)" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validate, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			# Remove the file which contains the password crypted
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validate, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
 	# Attempt to delete virtual machine from inventory vSphere
		try{
		# Ask the user to specify the name of virtual machine he want delete from inventory vSphere
		$Name=read-host "Specify the name ov virtual machine you want delete from inventory vSphere" 
		# Command to delete virtual machine from inventory vSphere
		Remove-VM -VM $Name -Confirm:$false -ErrorAction Stop
		# If the virtual machine has been deleted from inventory vSphere display a message succes
    	if ($? -eq $true){
			write-host "SUCCES : The virtual machine $Name has been deleted from inventory vSphere" -ForegroundColor green
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
       	}
	}
	catch{
		# As long as the attempt of deletion virtual machine from inventory vSphere failed the fields are reasked (reason read write-host below)
    	while ($? -eq $false) {
			write-host "ERROR : There are a error, fill all fields else check if the virtual machine is stopped, the name is correct or others issue" -ForegroundColor red
			$Name=read-host "Specify the name ov virtual machine you want delete from inventory vSphere" 
			# Command to delete virtual machine from inventory vSphere
			Remove-VM -VM $Name -DeleteFromDisk:$true -Confirm:$false -ErrorAction Continue
			# If the virtual machine has been deleted from inventory vSphere display a message succes
        	if ($? -eq $true){
				write-host "SUCCES : The virtual machine $Name has been deleted from inventory vSphere" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds from inventory vSphere" -ForegroundColor Gray
				Timeout /t 10
				return
        	}
    	}
	}
	# If the virtual machine has not been deleted from inventory vSphere display a message error and return to the homepage (reason read write-host below)
	if ($? -eq -$false){
		write-host "Despite your two attempts it did not work, field may be empty, virtual machine not stopped, wrong character entered, not exists or others issue try again later" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function StartVM
# Allows to start specialy a virtual machine 
Function StartVM {
	write-host "You want start a virtual machine" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			# Remove the file which contains the password crypted
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
 	# Attempt to start virtual machine
		try{
		# Ask the user to specify the name of virtual machine he want start
		$Name=read-host "Specify the name of virtual machine you want start" 
		# Command to start virtual machine
		Start-VM -VM $Name -Confirm:$false -ErrorAction Stop
		# If the virtual machine has been started display a message succes
    	if ($? -eq $true){
			write-host "SUCCES : The virtual machine $Name has been started" -ForegroundColor green
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
       	}
	}
	catch{
		# As long as the attempt to start virtual machine failed the fields are reasked (reason read write-host below)
    	while ($? -eq $false) {
        	write-host "ERROR : There are a error, fill all fields else check if the name is correct or others issue" -ForegroundColor red
			$Name=read-host "Specify the name of virtual machine you want start" 
			# Command to start virtual machine
			Start-VM -VM $Name -Confirm:$false -ErrorAction Continue
			# If the virtual machine has been start display a message succes
        	if ($? -eq $true){
				write-host "SUCCES : The virtual machine $Name has been started" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
        	}
    	}
	}
	# If the virtual machine has not been started display a message error and return to the homepage (reason read write-host below)
	if ($? -eq -$false){
    	write-host "ERROR : Despite your two attempts it did not work, field may be empty, wrong character entered, not exists, already started or others issue try again later" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function StopVM
# Allows to stop specialy a virtual machine 
Function StopVM {
	write-host "You want stop a virtual machine" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
 	# Attempt to stop virtual machine
	try{
		# Ask the user to specify the name of virtual machine he want stop
		$Name=read-host "Specify the name of virtual machine you want stop"
		# Command to stop virtual machine 
		Stop-VM -VM $Name -Confirm:$false -ErrorAction Stop
		# If the virtual machine has been stopped display a message succes
    	if ($? -eq $true){
			write-host "SUCCES : The virtual machine $Name has been stopped" -ForegroundColor green
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
       	}
	}
	catch{
		# As long as the attempt to stop virtual machine failed the fields are reasked (reason read write-host below)
    	while ($? -eq $false) {
        	write-host "ERROR : There are a error, fill all fields else check if the name is correct or others issue" -ForegroundColor red
			$Name=read-host "Specify the name of virtual machine you want stop" 
			# Command to stop virtual machine
			Stop-VM -VM $Name -Confirm:$false -ErrorAction Continue
			# If the virtual machine has been stopped display a message succes
        	if ($? -eq $true){
				write-host "SUCCES : The virtual machine $Name has been stopped" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
        	}
    	}
	}
	# If the virtual machine has not been stopped display a message error and return to the homepage (reason read write-host below)
	if ($? -eq -$false){
		
    	write-host "ERROR : Despite your two attempts it did not work, field may be empty, wrong character entered, not exists, suspend, already stopped or others issue try again later" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function StopPowersupply
# Allows to stop specialy a virtual machine but by powersupply (Kill)
Function StopPowersupply {
	write-host "You want stop a virtual machine by power supply (kill)" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
 	# Attempt to stop (PowerSupply - Kill) virtual machine
		try{
		# Ask the user to specify the name of virtual machine he want stop (PowerSupply - Kill)
		$Name=read-host "Specify the name of virtual machine you want stop by power supply (kill)" 
		# Command to stop virtual machine 
		Stop-VM -VM $Name -Kill -Confirm:$false -ErrorAction Stop
		# If the virtual machine has been stoped (PowerSupply - Kill) display a message succes
    	if ($? -eq $true){
			write-host "SUCCES : The virtual machine $Name has been stopped by power supply (kill)" -ForegroundColor green
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
       	}
	}
	catch{
		# As long as the attempt to stop (PowerSupply - Kill) virtual machine failed the fields are reasked (reason read write-host below)
    	while ($? -eq $false) {
        	write-host "ERROR : There are a error, fill all fields else check if the name is correct or others issue" -ForegroundColor red
			$Name=read-host "Specify the name of virtual machine you want stop by power supply (kill)" 
			# Command to stop (PowerSupply - Kill) virtual machine
			Stop-VM -VM $Name -Kill -Confirm:$false -ErrorAction Continue
			# If the virtual machine has been stopped (PowerSupply - Kill) display a message succes
        	if ($? -eq $true){
				write-host "SUCCES : The virtual machine $Name has been stopped by power supply (kill)" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
        	}
    	}
	}
	# If the virtual machine has not been stopped (PowerSupply - Kill) display a message error and return to the homepage (reason read write-host below)
	if ($? -eq -$false){
    	write-host "ERROR : Despite your two attempts it did not work, field may be empty, wrong character entered, not exists, suspend, already stopped or others issue try again later" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function SuspendVM
# Allows to suspend specialy a virtual machine 
Function SuspendVM { 
	write-host "You want suspend a virtual machine" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
 	# Attempt to suspend virtual machine
	try{
		# Ask the user to specify the name of virtual machine he want suspend
		$Name=read-host "Spechify the name of virtual machine you want suspend" 
		# Command to suspend virtual machine 
		Suspend-VM -VM $Name -Confirm:$false -ErrorAction Stop
		# If the virtual machine has been suspended display a message succes
   		if ($? -eq $true){
			write-host "SUCCES : The virtual $Name has been suspended" -ForegroundColor green
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
    	}
	}
	catch{
		# As long as the attempt to suspend virtual machine failed the fields are reasked (reason read write-host below)
    	while ($? -eq $false) {
        	write-host "ERROR : There are a error, fill all fields else check if the name is correct or others issue" -ForegroundColor red
			$Name=read-host "Spechify the name of virtual machine you want suspend" 
			# Command to suspendvirtual machine
			Suspend-VM -VM $Name -Confirm:$false -ErrorAction Continue
			# If the virtual machine has been suspended display a message succes
        	if ($? -eq $true){
				write-host "SUCCES : The virtual $Name has been suspended" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
        	}
    	}
	}
	# If the virtual machine has not been suspended display a message error and return to the homepage (reason read write-host below)
	if ($? -eq -$false){
    	write-host "ERROR : Despite your two attempts it did not work, field may be empty, wrong character entered, not exists, already suspend, stopped or others issue try again later" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function RestartVM
# Allows to restart specialy a virtual machine 
Function RestartVM { 
	write-host "You want restart a virtual machine" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
 	# Attempt to restart virtual machine
	try{
		# Ask the user to specify the name of virtual machine he want restart
		$Name=read-host "Specify the name of virtual machine you want restart" 
		# Command to restart virtual machine 
		Restart-VM -VM $Name -Confirm:$false -ErrorAction Stop
		# If the virtual machine has been restarted display a message succes
    	if ($? -eq $true){
			write-host "SUCCES : The virtual machine $Name has been restarted" -ForegroundColor green
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
       	}
	}
	catch{
		# As long as the attempt to restart virtual machine failed the fields are reasked (reason read write-host below)
    	while ($? -eq $false) {
        	write-host "ERROR : There are a error, fill all fields else check if the name is correct or others issue" -ForegroundColor red
			$Name=read-host "Specify the name of virtual machine you want restart" 
			# Command to restart virtual machine
			Restart-VM -VM $Name -Confirm:$false -ErrorAction Continue
			# If the virtual machine has been restarted display a message succes
        	if ($? -eq $true){
				write-host "SUCCES : The virtual machine $Name has been restarted" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
        	}
    	}
	}
	# If the virtual machine has not been restarted display a message error and return to the homepage (reason read write-host below)
	if ($? -eq -$false){
    	write-host "ERROR : Despite your two attempts it did not work, field may be empty, wrong character entered, not exists, stopped, suspended or others issue try again later" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function GetVM
# Allows to get specialy if a virtual machine exists
Function GetVM { 
	write-host "You want check if a virtual machine exists" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
 	# Attempt to check if virtual machine exists
	try{
		# Ask the user to specify the name of virtual machine he want check if exists
		$Name=read-host "Secify the name of virtual machine you want check if exists" 
		# Command to check if virtual machine exists
		Get-VM -Name $Name -ErrorAction Stop
		# If the virtual machine has been finded display a message succes
    	if ($? -eq $true){
			write-host "SUCCES : The virtual machine $Name exists" -ForegroundColor green
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
       	}
	}
	catch{
		# As long as the attempt to check if virtual machine exists failed the fields are reasked (reason read write-host below)
    	while ($? -eq $false) {
        	write-host "ERROR : There are a error, fill all fields else virtual machine not exists so check if the name is correct" -ForegroundColor red
			$Name=read-host "Secify the name of virtual machine you want check if exists" 
			# Command to check if virtual machine exists
			Get-VM -Name $Name -ErrorAction Continue
			# If the virtual machine has been finded display a message succes
        	if ($? -eq $true){
				write-host "SUCCES : The virtual machine $Name exists" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
        	}
    	}
	}
	# If the virtual machine has not been finded display a message error and return to the homepage (reason read write-host below)
	if ($? -eq -$false){		
    	write-host "ERROR : Despite your two attempts it did not work, field may be empty, wrong character or name entered, not exists or others issue try again later" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function CreateFolder
# Allows to create a folder location for the virtual machines in vSphere 
Function CreateFolder { 
	write-host "You want create a folder in vSphere" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted	
	Remove-Item $PathSecurityPassword
 	# Attempt to create a folder from vSphere
		try{
		# Ask the user to specify the name of folder he want create from vSphere
		$Name=read-host "Specify the name of folder you want create in vSphere" 
		# Command to create folder from vSphere
		New-Folder -Name $Name -Location (Get-Folder vm) -confirm:$false -ErrorAction stop
		# If the folder has been created display a message succes
    	if ($? -eq $true){
			write-host "SUCCES : The folder $Name has been created in vSphere" -ForegroundColor green
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
       	}
	}
	catch{
		# As long as the attempt to create a folder from vSphere failed the fields are reasked (reason read write-host below)
    	while ($? -eq $false) {
        	write-host "ERROR : There are a error, fill all fields else check if already exists or others issue" -ForegroundColor red
			$Name=read-host "Specify the name of folder you want create in vSphere" 
			# Command to screate folder from vSphere
			New-Folder -Name $Name -Location (Get-Folder vm) -confirm:$false -ErrorAction Continue
			# If the folder has been created display a message succes
        	if ($? -eq $true){
				write-host "SUCCES : The folder $Name has been created in vSphere" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
        	}
    	}
	}
	# If the creation a folder from vSphere has not been created display a message error and return to the homepage (reason read write-host below)
	if ($? -eq -$false){
    	write-host "ERROR : Despite your two attempts it did not work, field may be empty, wrong character entered, already exists or others issue try again later" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function ModifyValue
# Allows to modifyvalue in csv file which is present many times
Function ModifyValue {
	# Ask the user to specify the location of the CSV
	write-host "You want modifie a value in CSV file" -ForegroundColor gray
	$LocationCSV=read-host 'Specify the location of the sample CSV file "Exemple : (C:/windows/Kyosuko.csv)"'
	# Check if the CSV file exists with the extension .csv
	$CheckLocationCSV=Get-Item $LocationCSV ; $CheckLocationCSV.Extension
	# If the file exists, a message, success and warning is displayed
	if ($CheckLocationCSV.Extension -eq ".csv") {
    	write-host "The file specifed exist with the good extension .csv" -ForegroundColor green
	}
	# As long as the file specified in the $LocationCSV variable is not a csv file, a new entry is displayed with an error message
	While ($CheckLocationCSV.Extension -ne ".csv") {
		write-host "The file than you have specify is not valide check is it's the good path or if there are the extension .csv" -ForegroundColor red
		$LocationCSV=read-host "Specify the location of the sample CSV file Exemple : (C:/windows/Kyosuko.csv)"
		$CheckLocationCSV=Get-Item $LocationCSV ; $CheckLocationCSV.Extension
		if ($CheckLocationCSV.Extension -eq ".csv") {
    		#Asks the user to specify the delimiter of the CSV file
    		write-host "The file specifed exist with the good extension .csv" -ForegroundColor green
		}
	}
	# Commands which allow to specify the old value with a new then check the content in the csv file find the old value and replace by the new
	# Display a message succes with timeout
	$OldValue=read-host "Which value you want modify ? "
	$NewValue=read-host "Which value you want give it ?"
	$ReplaceValue= Get-content "$LocationCSV" | foreach { $_ -replace $OldValue,$NewValue }
	Set-Content -Path "$LocationCSV" -Value $ReplaceValue
	write-host "SUCCES : The value "$OldValue", has been replaced by "$NewValue" if nothing has been modify, it's because the value "$Value" not exists" -ForegroundColor green
	write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
	Timeout /t 10
	return
}

## Function GetVMCreate
# Allows to get the last date creation of virtual machine Exemple if deleted and recreated with
# the same name get this date not the first when the virtual machine with this name has been created
Function GetVMCreate { 
	write-host "You want check the last date creation of virtual machine" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
 	# Attempt to check last creation date of virtual machine
	try{
		# Ask the user to specify the name of virtual machine he want to check the last creation date 
		$Name=read-host "Specify the name of virtual machine you want check the last date of creation" 
		# Command to check the last creation date 
		Get-VM -Name $Name -ErrorAction Stop |ForEach-Object -Process {
			Get-VIEvent -Entity $_ -MaxSamples ([int]::MaxValue) |
			where { "VmCreatedEvent" -contains $_.GetType().Name } |
			Sort-Object -Property CreatedTime -Descending |
			Select -First 1 |
			Foreach-Object {
				New-Object PSObject -Property ([ordered]@{
				Name = $_.VM.Name
					Created = $_.CreatedTime
					 User = $_.UserName
				})
			} 
		} 
		# If it find the last creation date of virtual machine display a message success
        	if ($? -eq $true){
				write-host "SUCCES : Below the last date creation of virtual machine $Name and by who" -ForegroundColor green
				Timeout /t 2
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
        	}
	}
	catch{
		# As long as the attempt to find the last creation date of virtual machine failed the fields are reasked (reason read write-host below)
    	while ($? -eq $false) {
        	write-host "ERROR : There are a error, fill all fields else check if the name is correct or others issue" -ForegroundColor red
			$Name=read-host "Specify the name of virtual machine you want check the last date of creation" 
			# Command to check the last creation date 
			Get-VM -Name $Name -ErrorAction Continue |ForEach-Object -Process {
				Get-VIEvent -Entity $_ -MaxSamples ([int]::MaxValue) |
				where { "VmCreatedEvent" -contains $_.GetType().Name } |
				Sort-Object -Property CreatedTime -Descending |
				Select -First 1 |
				Foreach-Object {
					New-Object PSObject -Property ([ordered]@{
						Name = $_.VM.Name
						Created = $_.CreatedTime
						 User = $_.UserName
						})
					}
				} 
			# If it find the last creation date of virtual machine display a message success
        	if ($? -eq $true){
				write-host "SUCCES : Above the last date creation of virtual machine $Name and by who" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
        	}
    	}
	}
	# If the attempt to find the last creation date of virtual machin failed display a message error and return to the homepage (reason read write-host below)
	if ($? -eq $false){
    	write-host "ERROR : Despite your two attempts it did not work, field may be empty, wrong character entered, not exists or others issue try again later" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function PowerCLI
# Allows to install PowerCLI in the workstation or server
Function PowerCLI {
	write-host "You want install PowerCLI" -ForegroundColor gray
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not installed" -ForegroundColor red
		$ChoicePC=read-host "Do you want install PowerCLI ? [Y] for Yes, [N] for No`
If [Y] Yes not cut during the downloading"
	}
	else{
		$ChoicePC="Installed"
		write-host "SUCCES : PowerCLI is already installed" -ForegroundColor green
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	if ($ChoicePC -eq $ChoiceYes){
		try {
			# Commands to put Tls version and install module vmware and Nuget which allows find and download the module
			# PowerCLI since the "PSGallery"
			write-host "MESSAGE : You have chosen to install PowerCLI" -ForegroundColor cyan
			write-host 'Not cut during the installation, please wait' -ForegroundColor yellow
			[Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls" 
			Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -confirm:$false -ErrorAction Stop
			Set-PSRepository -Name "PSGallery" -InstallationPolicy Trusted -ErrorAction Stop
			Install-Module -Name VMware.PowerCLI -Scope CurrentUser -confirm:$false -ErrorAction Stop
		}
		catch {
			write-host "ERROR : PowerCLI has not been installed, try resolve this issue" -ForegroundColor red
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
	}
	elseif ($ChoicePC -eq $ChoiceNo){
		write-host "MESSAGE : You have chosen to not install Power CLI, try resolve the issue" -ForegroundColor Magenta
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# As long as the choice is not Y,N or already installed the question is reasked if he want install PowerCLI and after choice
	# if it's yes it install else return to the homepage
	while (($ChoicePC -ne $ChoiceYes) -and ($ChoicePC -ne $ChoiceNo) -and ($ChoicePC -ne "Installed")){
		$ChoicePC=read-host "Do you want install PowerCLI ? [Y] for Yes, [N] for No`
	If [Y] Yes not cut during the downloading"
		if ($ChoicePC -eq $ChoiceYes){
			try {
				# Commands to put Tls version and install module vmware and Nuget which allows find and download the module
				# PowerCLI since the "PSGallery"
				write-host "MESSAGE : You have chosen to install PowerCLI" -ForegroundColor cyan
				write-host 'Not cut during the installation, please wait' -ForegroundColor yellow
				[Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls" 
				Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -confirm:$false -ErrorAction Stop
				Set-PSRepository -Name "PSGallery" -InstallationPolicy Trusted -ErrorAction Stop
				Install-Module -Name VMware.PowerCLI -Scope CurrentUser -confirm:$false -ErrorAction Stop
			}
			catch {
				write-host "ERROR : PowerCLI has not been installed, try resolve this issue" -ForegroundColor red
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
			}
		}
		elseif ($ChoicePC -eq $ChoiceNo){
			write-host "MESSAGE : You have chosen to not install PowerCLI, try resolve the issue" -ForegroundColor Magenta
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
		}
	}
	# Command to import Module PowerCli after installation with timeout between last action and return to the homepage
	# Allows to ignorate certificate no valide but disable if you a certificate
	write-host "INFORMATION : Please wait importation of module PowerCLI" -ForegroundColor gray
	Import-Module VMware.PowerCLI
	Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
	write-host "SUCCES : PowerCLI has been installed" -ForegroundColor green
	write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
	Timeout /t 10
	return
}

## Function DisconnectAll
# Allows to disconnect everybody connected in vSphere (consoles)
Function DisconnectAll {
	write-host "Disconnect all active consoles connected to vSphere" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			# Remove the file which contains the password crypted
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
	# Attempt to disconnect all active consoles connected
	# Display a message with a timeout fort run the command to disconnect
	Write-Host "WARNING : Disconnection of all consoles active connected on vSphere in 10 seconds" -ForegroundColor Yellow
	timeout /t 10
	# Commands to disconnect all active consoles connected
	try{
		$ServiceInstance = Get-View ServiceInstance -ErrorAction silentlycontinue
		$SessionManager = Get-View $ServiceInstance.Content.SessionManager -ErrorAction silentlycontinue
		$SessionManager.SessionList | ForEach-Object {$SessionManager.TerminateSession($_.Key)} -ErrorAction silentlycontinue
	}
	# Because the commands above disconnect all connections active consoles and try also this console but he his reconnected after
	# so there are message error juste for that but the others connections are disconnected.
	catch{
	}
	# If the active consoles are been disconnected display a message success
	write-host "SUCCES : The logout of all consoles active connected on $NamevSphereServer has been a success" -ForegroundColor green
	write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
	Timeout /t 10
	return
}

## Function RenameVM
# Allows to rename specialy a virtual machine 
Function RenameVM {
	write-host "You want rename a virtual machine from vSphere" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			# Remove the file which contains the password crypted
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
 	# Attempt to rename virtual machine
	try{
		# Ask the user to specify the name of virtual machine he want rename
		$Name=read-host "Specify the name of virtual machine you want rename from vSphere" 
		$NewName=read-host "Specify the new name of virtual machine you want give" 
		# Commands to rename virtual machine
		Get-VM -Name $Name -ErrorAction Stop 
		Set-VM -VM $Name -Name $NewName -confirm:$false -ErrorAction Stop
		# If the virtual machine has been renamed display a message succes
        if ($? -eq $true){
			write-host "SUCCES : The virtual $Name has been renamed to $NewName" -ForegroundColor green
			write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
			Timeout /t 10
			return
        }
	}
	catch{
		# As long as the attempt of rename virtual machine failed the fields are reasked (reason read write-host below)
    	while ($? -eq $false) {
        	write-host "ERROR : There are a error, fill all fields else check if the name is correct or others issue" -ForegroundColor red
			$Name=read-host "Specify the name of virtual machine you want rename from vSphere" 
			$NewName=read-host "Specify the new name of virtual machine you want give" 
			# Commands to rename virtual machine
			Get-VM -Name $Name -ErrorAction continue 
			Set-VM -VM $Name -Name $NewName -confirm:$false -ErrorAction continue
			# If the virtual machine has been renamed display a message succes
        	if ($? -eq $true){
				write-host "SUCCES : The virtual $Name has been renamed to $NewName" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
        	}
    	}
	}
	# If the virtual machine has not been renamed display a message error and return to the homepage (reason read write-host below)
	if ($? -eq $false){
    	write-host "ERROR : Despite your two attempts it did not work, field may be empty, wrong character entered, not exists or others issue try again later" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function Inventory
# Allows to display the informations about invetory (virtual machines, datastores, hypervisors, vSwitchs, clusters, datacenters)
Function InventoryManagement {
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	write-host "You want display the informations about a invetory from vSphere" -ForegroundColor gray
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			# Remove the file which contains the password crypted
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# If the fields is null the message error display with the homepage return message and command "Remove-Item" which allows to remove the file contain the password crypted
	if ($? -eq -$false){
		Remove-Item $PathSecurityPassword
		write-host "ERROR : Despite your two attempts, this did not work empty field, bad character used or server state" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
	Jumpline
	# Display the list of choices inventory
	write-host "List of choices inventory available to display : " -ForegroundColor gray
	Jumpline
	write-host "	[----------------------------------]
	| > Inventory Table                |
	|----------------------------------|
	| 1 - Virtual Machines             |
	| 2 - Hypervisors                  |
	| 3 - Datastores                   |
	| 4 - vSwitchs                     |
	| 5 - Clusters                     |
	| 6 - Datacenters                  |
	| 7 - Return to the homepage       |
	[----------------------------------]" -ForegroundColor gray
	Jumpline
	# It's is range until 7
	$ListChoices=1..7
	# Ask the user to choice of inventory between 1 and 7 and he want display 
	# [int] to specify only number
	[int]$ChoiceInventory=read-host "What do you want display like inventory ?"
	# As long as the choice is not between 1 and 7 the fill is reasked and display a error message
	while ($ChoiceInventory -notin $ListChoices){
		write-host "ERROR : Select a choice between 1 and 7" -ForegroundColor red
		[int]$ChoiceInventory=read-host "What do you want display like inventory ?"
	}
	# If the choice is between 1 and 7 display a choice selected
	if (($? -eq $true) -and ($ChoiceInventory -in $Listchoices)){
		# Switch allows to make a list of choice
		switch ($ChoiceInventory) {
			1 { write-host "SUCCES : You have selected choice 1 - Virtual machines" -ForegroundColor green
				write-host "Display of inventory virtual machines in 10 seconds" -ForegroundColor Gray	
				timeout /t 10
				$Check=Get-VM;$Check | format-table
				if ([string]::IsNullOrEmpty($Check)){
					write-host "ERROR : There a not virtual machines installed on the server $NamevSphereServer" -ForegroundColor Red
					write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
					Timeout /t 10
					return
				}
				write-host "SUCCES : Above you have the inventory in format table " -ForegroundColor green
				write-host "Return to the homepage in 1 minute" -ForegroundColor Gray
				Timeout /t 60
				return
			}
			2 { write-host "SUCCES : You have selected choice 2 - Hypervisors" -ForegroundColor green 
				write-host "Display of inventory hypervisors in 10 seconds" -ForegroundColor Gray	
				timeout /t 10
				$Check=Get-VMHost;$Check | format-table
				if ([string]::IsNullOrEmpty($Check)){
					write-host "ERROR : There a not hypervisors installed on the server $NamevSphereServer" -ForegroundColor Red
					write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
					Timeout /t 10
					return
				}
				write-host "SUCCES : Above you have the inventory in format table " -ForegroundColor green
				write-host "Return to the homepage in 1 minute" -ForegroundColor Gray
				Timeout /t 60
				return
			}
			3 { write-host "SUCCES : You have selected choice 3 - Datastores" -ForegroundColor green 
				write-host "Display of inventory datastores in 10 seconds" -ForegroundColor Gray	
				timeout /t 10
				$Check=Get-Datastore;$Check | format-table
				if ([string]::IsNullOrEmpty($Check)){
					write-host "ERROR : There a not datastores installed on the server $NamevSphereServer" -ForegroundColor Red
					write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
					Timeout /t 10
					return
				}
				write-host "SUCCES : Above you have the inventory in format table " -ForegroundColor green
				write-host "Return to the homepage in 1 minute" -ForegroundColor Gray
				Timeout /t 60
				return
			}
			4 { write-host "SUCCES : You have selected choice 4 - vSwitchs" -ForegroundColor green 
				write-host "Display of inventory vswitchs in 10 seconds" -ForegroundColor Gray	
				timeout /t 10
				$Check=Get-VirtualSwitch;$Check | format-table
				if ([string]::IsNullOrEmpty($Check)){
					write-host "ERROR : There a not vswitchs installed on the server $NamevSphereServer" -ForegroundColor Red
					write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
					Timeout /t 10
					return
				}
				write-host "SUCCES : Above you have the inventory in format table " -ForegroundColor green
				write-host "Return to the homepage in 1 minute" -ForegroundColor Gray
				Timeout /t 60
				return
			}
			5 { write-host "SUCCES : You have selected choice 5 - Clusters" -ForegroundColor green 
				write-host "Display of inventory clusters in 10 seconds" -ForegroundColor Gray	
				timeout /t 10
				$Check=Get-Cluster;$Check | format-table
				if ([string]::IsNullOrEmpty($Check)){
					write-host "ERROR : There a not clusters installed on the server $NamevSphereServer" -ForegroundColor Red
					write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
					Timeout /t 10
					return
				}
				write-host "SUCCES : Above you have the inventory in format table " -ForegroundColor green
				write-host "Return to the homepage in 1 minute" -ForegroundColor Gray
				Timeout /t 60
				return
			}
			6 { write-host "SUCCES : You have selected choice 6 - Datacenters" -ForegroundColor green 
				write-host "Display of inventory datacenters in 10 seconds" -ForegroundColor Gray	
				timeout /t 10
				$Check=Get-Datastore;$Check | format-table
				if ([string]::IsNullOrEmpty($Check)){
					write-host "ERROR : There a not datastores installed on the server $NamevSphereServer" -ForegroundColor Red
					write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
					Timeout /t 10
					return
				}
				write-host "SUCCES : Above you have the inventory in format table " -ForegroundColor green
				write-host "Return to the homepage in 1 minute" -ForegroundColor Gray
				Timeout /t 60
				return
			}
			7 { write-host "SUCCES : You have selected choice 6 - Return to the homepage" -ForegroundColor green
				write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
				Timeout /t 10
				return
			}
		}
	}
}

## Function Import ISO
# Allows to import a iso file on the datastore specified
Function ImportISO {
	write-host "You want import a ISO file in datacenter" -ForegroundColor gray
	# A check if PowerCLI is installed if it's not installed return to the homepage and display install with option 18
	# Command Check if the module Vmware is available
	$CheckPowerCLI=Get-Command -Module *VMWare*
	if ([string]::IsNullOrEmpty($CheckPowerCLI)){
		write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# Ask to specify the credentials to connect on vSphere and if it's good message succes is displayed
	$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
	$UservSphereServer=read-host "! Specify the username authorized to connect !"
	read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
	try{
		# Command to connect on the vSphere
		Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
		(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Stop
		if ($? -eq $true){
			write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
		}
	}
	catch{
		# As long as the connection failed the fields is redisplay to enter the credentials and if it's good message succes is displayed
		while ($?-eq $false) {
			# Remove the file which contains the password crypted
			Remove-Item $PathSecurityPassword
			write-host "ERROR : Connection failed check hostname, user, password or the state of server" -ForegroundColor red
			$NamevSphereServer=read-host "! Specify the name of the vSphere on which you want to connect !"
			$UservSphereServer=read-host "! Specify the username authorized to connect !"
			read-host "! Specify the password of the account authorized to connect !" -AsSecureString | ConvertFrom-SecureString | Out-File -FilePath $PathSecurityPassword -confirm:$false
			# Command to connect on the vSphere
			Connect-VIServer -Server $NamevSphereServer -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "$UservSphereServer",
			(Get-Content -Path $PathSecurityPassword | ConvertTo-SecureString)) -ErrorAction Continue
			if ($? -eq $true){
				write-host "SUCCES : Connection validated, Welcome" -ForegroundColor green
			}
		}
	}
	# Command "Remove-Item" which allows to remove the file contain the password crypted
	Remove-Item $PathSecurityPassword
	# Attempt to import iso file in datastore
	# Ask the user to specify the location of iso file after a command to check the extension of iso
	$LocationISO=read-host 'Specify the location of ISO file "Exemple : (C:/windows/Kyosuko.iso)"'
	$CheckLocationISO=Get-Item $LocationISO ; $CheckLocationISO.Extension
	# As long as the file has not extension .iso the input field is asked to fill the field with good path
	While ($CheckLocationISO.Extension -ne ".iso") {
		write-host 'ERROR : The file than you have specify is not valide check if it''s the good path or if there are the extension ".iso"' -ForegroundColor red
		$LocationISO=read-host 'Specify the location of ISO file "Exemple : (C:/windows/Kyosuko.iso)"'
		$CheckLocationISO=Get-Item $LocationISO; $CheckLocationISO.Extension
		if ($CheckLocationISO.Extension -eq ".iso") {
			write-host "SUCCES : The file specifed exist with the good extension .iso" -ForegroundColor green
		}
	}
	# Ask to the user specify the name of datacenter of respect the case sensitivity and it's okay display a success message
	write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
	$LocationDatacenter=read-host 'Specify the datacenter you want import the ISO file "Exemple : Datacenter"'
	# As long as the field is empty the input field is asked with error and warning message else it's okay display a success message
	while ([string]::IsNullOrEmpty($LocationDatacenter)){
		write-host "ERROR : Please fill all fields, good name or others issue" -ForegroundColor red
		write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
		$LocationDatacenter=read-host 'Specify the Datacenter you want import the ISO file "Exemple : Datacenter"'
	}
	# Command to check if the name of datacenter specified exists and it's yes print success message
	$CheckDatacenter=Get-Datacenter $LocationDatacenter
	if ($? -eq $true) {
		write-host "SUCCESS : The datacenter entered will be used" -ForegroundColor green
	}
	# As long as the name entered is not good the input field is asked with error and warning message else it's okay display a success message
	While ($?-eq $false) {
		write-host 'ERROR : The datacenter you have specify is not valide check if it''s the good name' -ForegroundColor red
		write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
		$LocationDatacenter=read-host 'Specify the datacenter you want import the ISO file "Exemple : Datacenter"'
		# As long as the field is empty the input field is asked with error and warning message else it's okay display a success message
		while ([string]::IsNullOrEmpty($LocationDatacenter)){
			write-host "ERROR : Please fill all fields, good name or others issue" -ForegroundColor red
			write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
			$LocationDatacenter=read-host 'Specify the datacenter you want import the ISO file "Exemple : Datacenter"'
		}
		# Command to check if the name of datacenter specified exists and it's yes print success message
		$CheckDatacenter=Get-Datacenter $LocationDatacenter
		if ($? -eq $true) {
			write-host "SUCCESS : The datacenter entered will be used" -ForegroundColor green
		}
	}
	# Ask to the user specify the name of datastore of respect the case sensitivity and it's okay display a succes message
	write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
	$LocationDatastore=read-host 'Specify the datastore you want import the ISO file "Exemple : KyosukoC2"'
	# As long as the field is empty the input field is asked with error and warning message else it's okay display a succes message
	while ([string]::IsNullOrEmpty($LocationDatastore)){
		write-host "ERROR : Please fill all fields, good name or others issue" -ForegroundColor red
		write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
		$LocationDatastore=read-host 'Specify the datastore you want import the ISO file "Exemple : KyosukoC2"'
	}
	# Command to check if the name of datastore specified exists and it's yes print success message
	$CheckDatastore=Get-Datastore $LocationDatastore
	if ($? -eq $true) {
		write-host "SUCCESS : The datastore entered will be used" -ForegroundColor green
	}
	# As long as the name entered is not good the input field is asked with error and warning message else it's okay display a success message
	While ($?-eq $false) {
		write-host 'ERROR : The datastore you have specify is not valide check if it''s the good name' -ForegroundColor red
		write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
		$LocationDatastore=read-host 'Specify the datastore you want import the ISOfile "Exemple : KyosukoC2"'
		# As long as the field is empty the input field is asked with error and warning message else it's okay display a success message
		while ([string]::IsNullOrEmpty($LocationDatastore)){
			write-host "ERROR : Please fill all fields, good name or others issue" -ForegroundColor red
			write-host "WARNING : Respect case sensitivity (Lowercase-Uppercase), because ESXi is based on system UNIX else not work" -ForegroundColor yellow
			$LocationDatastore=read-host 'Specify the datastore you want import the ISO file "Exemple : KyosukoC2"'
		}
		# Command to check if the name of datastore specified exists and it's yes print success message
		$CheckDatastore=Get-Datastore $LocationDatastore
		if ($? -eq $true) {
			write-host "SUCCESS : The datastore entered will be used" -ForegroundColor green
		}
	}
	write-host "WARNING : Please, not cut during the upload of iso file on datastore" -ForegroundColor yellow
	# Command to copy the iso file in the datastore
	Copy-DatastoreItem -Item "$LocationISO" -Destination "vmstore:\$LocationDatacenter\$LocationDatastore" 
	# If the copy has been effectuated display a message success
	if ($? -eq $true){
		write-host "SUCCESS : The iso file has been imported in the datastore $LocationDatastore" -ForegroundColor green
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
	# If the attempt of copy the iso in datastore has failed a message asked if the user want continue if yes it continue else return to the homepage
	elseif ($? -eq $false){
		write-host "ERROR : The iso file has not been imported in the datastore $LocationDatastore, check the case senstivity or others issue" -ForegroundColor red
		write-host "Return to the homepage in 10 seconds" -ForegroundColor Gray
		Timeout /t 10
		return
	}
}

## Function LegendColors
# Allows to display a list with the color codes used in the script AutoDeploy
Function Legendcolors {
# Command to display a list which contains the legends of colors used by the script
	write-host "
[----------------------------------]
| > Legends of colors for messages |
|----------------------------------|"
$Succes=write-host "| Succes = Green                   |" -ForegroundColor green
$Warning=write-host "| Warning = Yellow                 |" -ForegroundColor yellow
$FailError=write-host "| Fail/Error = Red                 |" -ForegroundColor red
$YesChoice=write-host "| Choice Yes = Cyan                |" -ForegroundColor cyan
$NoChoice=write-host "| Choice No =  Magenta             | " -ForegroundColor magenta
$Information=write-host "| Information = Gray              |" -ForegroundColor gray
write-host "[----------------------------------]"
Jumpline
write-host "Return to the homepage in 20 seconds" -ForegroundColor Gray
Timeout /t 20
return
}

## Function LeaveScript
# Allows to leave the script AutoDeploy
Function LeaveScript {
	# Allows to leave the script with a display message and timeout
	JumpLine
	$Leavescript=Get-content -Path .\src\Leave.tcsrc3 -Encoding UTF8
	$Leavescript
	JumpLine
	write-host "(: ! Thanks you for using this script by Kyosuko ! Bye ! :) " -ForegroundColor green
	timeout /t 7
	exit
}

###########################################################################
##### When the script is started by the user, this is where it starts
###########################################################################

# Allows to check if the module is installed if yes importation of module PowerCLI for the executions of commands 
# else message which say install PowerCLI with option 17
# ErroractionPreference "SIlentlyContinue" allows not to display some console error messages only those indicated in the script
$CheckPowerCLI=Get-Command -Module *VMWare*
$ErrorActionPreference = "SilentlyContinue"
if ([string]::IsNullOrEmpty($CheckPowerCLI)){
	write-host "ERROR : PowerCLI is not istalled, please install with the option 18 in homepage and retry" -ForegroundColor red
	write-host "Homepage display in 10 seconds" -ForegroundColor gray
	Timeout /t 10
}
else{
	# Allows to display message PowerCLI and import the module when the script is launched and clear the console
	# Allows to ignorate certificate no valide but disable if you a certificate
	# Disable warnning message (for the next use script : restart Power Shell necessary) to join 
	# "Vmware Customer Experience" to improve program
	write-host "SUCCES : PowerCLI is already installed" -ForegroundColor green
	write-host "INFORMATION : Please wait importation of module PowerCLI" -ForegroundColor gray
	Import-Module VMware.PowerCLI
	Set-PowerCLIConfiguration -Scope User -ParticipateINCEIP $false -confirm:$false
	Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
	Clear-Host
}

# Allows to display the choice table with the numbers redirected to the associated functions 
# in the loop until option 19 "leave" is selected for than after a function has finish his
# job it return here (choice table)
do {
	# Get the content of table choice and display 
	$Welcome=Get-content -Path "$LocationScript\src\Welcome.tcsrc3" -Encoding UTF8
	$Welcome
	# It's the number of choice than the user can used
	$Choicerange=1..21
	$ChoiceWelcome=$null
	Jumpline 
	write-host "Date and Time :" (Get-date)
	Jumpline
	# Allow the specify a choice but only number 
	[int]$ChoiceWelcome= read-host  "Select your choice" 
	# If the choice is between 1 and 21 display a message succes
	if (($ChoiceWelcome -in $Choicerange) -and ($? -eq $true)){
		write-host  "SUCCES : You have selected the choice $ChoiceWelcome" -ForegroundColor Green
	}
	# As long as the choice is not between 1 and 21 display a message error and reasked to make a choice
	while  ($? -eq $false){
		write-host "ERROR : You have not entered a value between 1 and 21" -ForegroundColor  red
		# Allow the specify a choice but only number 
		[int]$ChoiceWelcome=read-host "Select your choice" 
		# If the choice is between 1 and 21 display a message succes
   		if (($ChoiceWelcome -in $Choicerange) -and ($? -eq $true)){
       		write-host  "SUCCES : You have selected the choice $ChoiceWelcome" -ForegroundColor Green}
	}
	# As long as the choice is not between 1 and 21 display a message error and reasked to make a choice
	while  ($ChoiceWelcome -notin $Choicerange){
		write-host "ERROR : You have not entered a value between 1 and 21" -ForegroundColor  red
		[int]$ChoiceWelcome=read-host "Select your choice" 
		if ($ChoiceWelcome -in $Choicerange){
       		write-host  "SUCCES : You have selected the choice $ChoiceWelcome" -ForegroundColor Green
   		}
	}
	# If the choice is between 1 and 21 allows to be redirecy by the fuction selected
	if ($? -eq $true) {
		switch ($ChoiceWelcome) {
			1  {CreateVM}
			2  {CreateVMCSV}
			3  {CreateFolder}
			4  {DeleteVM}
			5  {DeleteVMCSV}
			6  {DeleteVMInventory}
			7  {ModifyValue}
			8  {StartVM}
			9  {StopVM}
			10 {StopPowersupply}
			11 {SuspendVM}
			12 {Restartvm}
			13 {RenameVM}
			14 {Getvm}
			15 {GetVMCreate}
			16 {DisconnectAll}
			17 {InventoryManagement}
			18 {PowerCLI}
			19 {ImportISO}
			20 {Legendcolors}
			21 {LeaveScript}
		}
	}
} until ($ChoiceWelcome -eq 21)

#[###########################################################################]
#[############################# By Kyosuko v1.0 #############################]
#[###########################################################################]
#[############################ To Mr "xx" ###########################]            
#[###########################################################################]