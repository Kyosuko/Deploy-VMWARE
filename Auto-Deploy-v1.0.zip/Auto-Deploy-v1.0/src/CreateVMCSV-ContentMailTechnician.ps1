"<head><style>.progress-bar-red { width:$($PourcentCreateVMFailCSS)px;height: 24px;padding: 4px;background: linear-gradient(#ff0000,#000000);border-radius: 16px;
-webkit-border-radius: 16px;-moz-border-radius: 16px;box-shadow: inset 0 1px 2px #000, 0 1px 0 #2b2b2b;-webkit-box-shadow: inset 0 1px 2px #000, 0 1px 0 #2b2b2b;-moz-box-shadow: inset 0 1px 2px #000, 0 1px 0 #2b2b2b;
}</style></head>
Hi, <b>$NameTechnicianBodyHTML</b> <p/> In this mail you can see the report sended about what happened on vSphere: <b>$NamevSphereServer</b><br><br>
<b>Virtual machine not created or not correctly : <font color=red><b>$($line.name)</font></b>
<div class=progress-bar-red><center><font color=white>N. $HTMLVMFail</font></center></div>
<br>Account used for the attempt of creation : <b><u><font color=1155CC>$UservSphereServer</b></font></u>
<i><u><br>List of parameters used during the attempt to create this virtual machine </i> :<br><br>
<center><table><tr><th>ESXi</th><th>Name</th><th>Datastore</th><th>RessourcePool</th><th>CPU</th><th>Memory (MB)</th><th>Disk Size (MB)</th><th>Type provisioning</th><th>CD</th><th>Floppy</th></tr>
<tr><td>$($line.VmHost)</td><td>$($line.name)</td><td>$($line.Datastore)</td><td>$($line.RessourcePool)</td><td>$($line.NumCPU)</td><td>$($line.MemoryMB)</td><td>$($line.DiskMB)</td><td>$($line.DiskStorageFormat)
</td><td>$($line.CD)</td><td>$($line.Floppy)</td></tr></center></table>
<i><u><br>List of errors during the attempt to create a virtual machine  at <b>$Hour hours $Minute minutes</u></i> :<br>"